# nachzahlung-frontend-e2e - Nachzahlung und Verzinsung E2E Test Starter

Dieses Repository dient als Startpunkt für die Erstellung von E2E-Tests mit Playwright und Cucumber auf Basis von Typescript.

Verantwortliches Team: **X-Force** 
Notes Gruppenname: `_DRV_rvEvolution_Team_X-Force`  

## Links
- [IT-Produkt NZV] (https://rvwiki.drv.drv/pages/viewpage.action?pageId=385515525)
- [X-Force Teamspace](https://rvwiki.drv.drv/pages/viewpage.action?pageId=374671349)

## Basis und Kudos
Die Inhalte basieren auf dem Repository [cucumber-playwright](https://github.com/Tallyb/cucumber-playwright)

## Installation
```
npm i
npx playwright install
```

## Verwendung

### Ausführung von Tests

`npm run test` zur Ausführung aller Tests

`npm run test features/<Featurename>` zur Ausführung eines einzelnen Features

#### Gezielte Ausführung von Testarten
Um nur eine bestimmte Art von Tests auszuführen, können Labels verwendet werden:

- `npm run test -- --tags @API` führt nur API-Tests aus.
- `npm run test -- --tags @UI` führt nur UI-Tests aus.
- `npm run test -- --tags @a11y` führt nur Barrierefreiheitstests (Accessibility) aus.
- `npm run test -- --tags @smoketest` führt nur Smoke-Tests aus.

Diese Labels können in den Feature- und Szenariodefinitionen in den Gherkin-Dateien verwendet werden, um die Tests entsprechend zu kennzeichnen.


### Browserverwendung
Per Default wird Chromium verwendet. Über die Umgebungsvariable `BROWSER` kann der Name eines alternativen Browsers gesetzt werden.

Mögliche Optionen: chromium, firefox, webkit

Beispiel für Windows
```
set BROWSER=firefox
npm run test
```

### Ignorieren eines Szenarios

Durch Verwendung des Tags `@ignore`

### Identifizieren von TypeScript, Linting oder Gherkin Fehlern

`npm run build`

### Auswertung der Step-Usage

`npm run steps-usage`

*Weitere Optionen/Befehle lassen sich aus dem [Basis-Repo](https://github.com/Tallyb/cucumber-playwright) entnehmen.

### Verwendung Gherkin Linter

Unter `.gherkin-lintrc` werden die entsprechenden Gherkin-Regeln konfiguriert.

`npm run gherkin` führt eine Validierung der Gherkin-Regeln durch.

### Sichten eines Playwright Trace
Zu jedem fehlgeschlagenen Szenario wird ein Trace im Ordner `trace` gespeichert.

Dieser Trace kann mittels `npx playwright show-trace <NAME-DES-TRACE>.zip` analysiert werden.

## Umgebungsvariablen

Die Konfiguration der Tests kann über Umgebungsvariablen in einer `.env`-Datei je nach Testumgebung angepasst werden. Hier eine Übersicht über die verfügbaren
 Variablen und ihre Bedeutung:

- `HEADLESS_MODE`: Steuert, ob der Browser im Headless-Modus läuft. `false` aktiviert die grafische Oberfläche. Gültige Werte: `true`, `false`.
- `BROWSER`: Legt den Browser für die Tests fest. Gültige Werte: `chromium`, `firefox`, `webkit`.
- `UI_URL`: URL der Frontend-Anwendung, z.B. `https://nzv-frontend-dev.apps.os-evo.entw.bund.drv`.
- `API_URL`: URL der Backend-API, z.B. `https://nzv-backend-dev.apps.os-evo.entw.bund.drv`.
- `KEYCLOAK_URL`: URL für Keycloak-Authentifizierung, z.B. `https://keycloak-rvevo-dev.apps.os-evo.entw.bund.drv/realms/rvEvoZentral/protocol/openid-connect/token`.
- `KEYCLOAK_CLIENT_ID`: Client-ID für Keycloak, z.B. `e2e-test`.

Für die Authentifizierung in Keycloak und anderen sensiblen Umgebungen werden Benutzernamen und Passwörter nicht direkt in der `.env`-Datei gespeichert.
 Stattdessen werden diese in Vault gespeichert und bei Bedarf abgerufen. Folgende Variablen verweisen auf die entsprechenden Credentials in Vault:

- `KEYCLOAK_USERNAME`
- `KEYCLOAK_PASSWORD`
- `KEYCLOAK_USERNAME_NO_ACCESS`
- `KEYCLOAK_PASSWORD_NO_ACCESS`
- `USER_TYPE`
- `DEV_USERNAME`
- `DEV_PASSWORD`
- `KEYCLOAK_USERNAME_NZV_GATEWAY`
- `KEYCLOAK_PASSWORD_NZV_GATEWAY`

Die Werte dieser Variablen können je nach Testbedarf angepasst werden.

