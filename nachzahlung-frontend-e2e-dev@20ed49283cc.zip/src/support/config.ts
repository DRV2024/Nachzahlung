import { LaunchOptions } from '@playwright/test';
import 'dotenv/config';

const isHeadless = process.env.HEADLESS_MODE !== 'false';

const browserOptions: LaunchOptions = {
  headless: isHeadless,
  slowMo: 0,
  args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--lang=de-DE'],
  firefoxUserPrefs: {
    'media.navigator.streams.fake': true,
    'media.navigator.permission.disabled': true,
  },
};

export const config = {
  timeout: {
    short: Number.parseInt(process.env.TIMEOUT_SHORT!),
    medium: Number.parseInt(process.env.TIMEOUT_MEDIUM!),
    long: Number.parseInt(process.env.TIMEOUT_LONG!),
  },

  browser: process.env.BROWSER!,
  browserOptions,
  IMG_THRESHOLD: { threshold: 0.4 },
  uiUrl: process.env.UI_URL!,
  apiUrl: process.env.API_URL!,
  keycloak: {
    baseUrl_TR_NzV_GW: process.env.KEYCLOAK_URL_TR_NzV_GW!,
    baseUrl_PR_NzV_BST_sb_no_role: process.env.KEYCLOAK_URL_PR_NzV_BST_sb_no_role!,
    clientId: process.env.KEYCLOAK_CLIENT_ID!,
    clientSecret_PR_NzV_BST_sb_no_role: process.env.KEYCLOAK_CLIENT_SECRET_PR_NzV_BST_sb_no_role!,
    PR_NzV_BST: {
      username: process.env.API_USERNAME!,
      password: process.env.API_PASSWORD!,
    },
    sb_no_role: {
      username: process.env.API_USERNAME_NO_ACCESS!,
      password: process.env.API_PASSWORD_NO_ACCESS!,
    },
    TR_NzV_GW: {
      username: process.env.API_USERNAME_NZV_GATEWAY!,
      password: process.env.API_PASSWORD_NZV_GATEWAY!,
    },
  },
  bestandsToken: {
    private_key: process.env.BESTANDS_JWT_PRIVATE_KEY!,
  },
};
export const userCredentials = new Map<string, { username: string; password: string }>([
  [
    'vollberechtigung_local',
    {
      username: process.env.UI_LOCAL_USERNAME!,
      password: process.env.UI_LOCAL_PASSWORD!,
    },
  ],
  [
    'vollberechtigung_dev',
    {
      username: process.env.UI_DEV_USERNAME!,
      password: process.env.UI_DEV_PASSWORD!,
    },
  ],
]);
//USER_TYPE
export const currentUserType = process.env.USER_TYPE!;

export function getBestandsPrivateKey() {
  return (
    '-----BEGIN EC PRIVATE KEY-----\n' +
    config.bestandsToken.private_key +
    '\n-----END EC PRIVATE KEY-----'
  );
}

export async function getKeycloakToken(role: 'PR_NzV_BST' | 'sb_no_role' | 'TR_NzV_GW') {
  const envConfig = config.keycloak;
  const credentials = envConfig[role];

  if (role === 'PR_NzV_BST' || role === 'sb_no_role') {
    const params = new URLSearchParams({
      client_id: 'idbroker',
      client_secret: envConfig.clientSecret_PR_NzV_BST_sb_no_role,
      grant_type: 'password',
      username: credentials.username,
      password: credentials.password,
      scope: 'openid',
    });

    const response = await fetch(envConfig.baseUrl_PR_NzV_BST_sb_no_role, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params,
    });

    if (!response.ok) {
      throw new Error(`Fehler beim Abrufen des Keycloak-Tokens: ${response.statusText}`);
    }

    const data = await response.json();
    const subjectToken = data.access_token;

    const exchangeParams = new URLSearchParams({
      client_id: 'idp-token-exchange',
      grant_type: 'urn:ietf:params:oauth:grant-type:token-exchange',
      subject_token: subjectToken,
      requested_token_type: 'urn:ietf:params:oauth:token-type:access_token',
      subject_issuer: 'APITEST-IDP',
      scope: 'clientscope-rvsm',
    });

    const exchangeResponse = await fetch(envConfig.baseUrl_TR_NzV_GW, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: exchangeParams,
    });

    if (!exchangeResponse.ok) {
      throw new Error(`Fehler beim Austauschen des Tokens: ${exchangeResponse.statusText}`);
    }

    const exchangeData = await exchangeResponse.json();
    return exchangeData.access_token;
  } else if (role === 'TR_NzV_GW') {
    const params = new URLSearchParams({
      client_id: envConfig.clientId,
      grant_type: 'client_credentials',
    });
    const clientSecret = process.env.KEYCLOAK_CLIENT_SECRET;
    if (clientSecret) {
      params.append('client_secret', clientSecret);
    }

    const response = await fetch(envConfig.baseUrl_TR_NzV_GW, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params,
    });

    if (!response.ok) {
      throw new Error(`Fehler beim Abrufen des Keycloak-Tokens: ${response.statusText}`);
    }

    const data = await response.json();
    return data.access_token;
  } else {
    // Handling für andere Rollen
    // ...
  }
}
