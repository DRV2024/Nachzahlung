/* eslint-disable indent */
/* eslint-disable prettier/prettier */
/* eslint-disable import/order */
// eslint-disable-next-line import/no-unresolved
import { browser as globalBrowser } from './common-hooks';
import { VorhandeneNachzahlungen } from '../pages/vorhandeneNachzahlungen';
import { NachzahlungUndAnsprüche } from '../pages/nachzahlungUndAnsprueche';
import { LoginPage } from '../pages/login';
import { ErstattungsanspruchForm } from '../pages/erstattungsanspruchForm';
import { VersichertenHeader } from '../pages/versichertenHeader';
import { Navigation } from '../pages/navigation';
import { AntragEingang } from '../pages/antragEingang';
import { VerzinsungUebersicht } from '../pages/verzinsungUebersicht';
import { SeitenFehler } from '../pages/seitenFehler';
import { setWorldConstructor, World, IWorldOptions } from '@cucumber/cucumber';
import type { Response as PlaywrightResponse } from '@playwright/test';
import * as messages from '@cucumber/messages';
import {
  BrowserContext,
  Page,
  PlaywrightTestOptions,
  APIRequestContext,
  APIResponse,
} from '@playwright/test';

import { promises as fs } from 'fs';
import { AntragsdatumÄnderung } from '../pages/AntragsdatumAenderung';
import { AuswahlRealmPage } from '../pages/auswahlRealm';
import { FehlendeBerichtigungPage } from '../pages/fehlendeBerechtigung';
export interface CucumberWorldConstructorParams {
  parameters: { [key: string]: string };
}

export interface ICustomWorld extends World {
  debug: boolean;
  feature?: messages.Pickle;
  context?: BrowserContext;
  page?: Page;
  auswahlRealmPage?: AuswahlRealmPage;
  fehlendeBerichtigungPage?: FehlendeBerichtigungPage;
  loginPage?: LoginPage;
  browser: typeof globalBrowser; // Fügen Sie das `browser`-Objekt hier hinzu
  vorhandeneNachzahlungen?: VorhandeneNachzahlungen;
  nachzahlungUndAnsprüche?: NachzahlungUndAnsprüche;
  erstattungsanspruchForm?: ErstattungsanspruchForm;
  versichertenHeader?: VersichertenHeader;
  navigation?: Navigation;
  verzinsungsUebersicht?: VerzinsungUebersicht;
  antragEingang?: AntragEingang;
  seitenFehler?: SeitenFehler;
  antragsdatumAenderung?: AntragsdatumÄnderung;

  testName?: string;
  startTime?: Date;

  requestContext?: APIRequestContext;
  requestPath?: string;
  requestParams?: { [key: string]: string | number | boolean };
  requestResponse?: APIResponse;
  tracedResponses?: PlaywrightResponse[];

  playwrightOptions?: PlaywrightTestOptions;
  requestBody?: any; //hier füge ich die RequestBody hinzu
  vorgangsId?: string;
  adressSchluessel?: string;
  accessToken?: string;
  bestandsToken?: string;
  generatedVorgangsId?: string; 
  saveStorageState(authFile: string): Promise<void>;
  setStorageState(storageState: any): Promise<void>;
}

export class CustomWorld extends World implements ICustomWorld {
  debug = false;
  context?: BrowserContext;
  page?: Page;
  browser = globalBrowser;
  generatedVorgangsId?: string; 

  constructor(options: IWorldOptions) {
    super(options);
  }

  async saveStorageState(authFile: string): Promise<void> {
    const storageState = await this.context?.storageState();
    await fs.writeFile(authFile, JSON.stringify(storageState));
  }
  async setStorageState(storageState: any): Promise<void> {
    await this.browser.contexts()[0].close();
    this.context = await this.browser.newContext({ storageState });
    this.page = await this.context.newPage();
  }
}

setWorldConstructor(CustomWorld);
