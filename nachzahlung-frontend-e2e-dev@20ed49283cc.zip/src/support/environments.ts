import { config } from '../support/config';

export const getUiBaseUrl = (): string => {
  const uiUrl = config.uiUrl;
  if (typeof uiUrl === 'undefined') {
    throw new Error('UI URL is not defined');
  }
  return uiUrl;
};

export const getApiBaseUrl = (): string => {
  const apiUrl = config.apiUrl;
  if (typeof apiUrl === 'undefined') {
    throw new Error('API URL is not defined');
  }
  return apiUrl;
};
