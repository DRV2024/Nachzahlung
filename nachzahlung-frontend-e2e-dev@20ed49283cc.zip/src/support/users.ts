export interface User {
  userName: string;
  password: string;
}

const testnutzer_Mandant17: User = {
  userName: process.env.UN_TESTNUTZER_MANDANT_17!,
  password: process.env.PW_TESTNUTZER_MANDANT_17!,
};

const gateway_Mandant17: User = {
  userName: process.env.UN_GATEWAY_MANDANT_17!,
  password: process.env.PW_GATEWAY_MANDANT_17!,
};

const bereitsteller_Mandant17: User = {
  userName: process.env.UN_BEREITSTELLER_MANDANT_17!,
  password: process.env.PW_BEREITSTELLER_MANDANT_17!,
};

const freigeber_Mandant17: User = {
  userName: process.env.UN_FREIGEBER_MANDANT_17!,
  password: process.env.PW_FREIGEBER_MANDANT_17!,
};

const auskunft_Mandant17: User = {
  userName: process.env.UN_AUSKUNFT_MANDANT_17!,
  password: process.env.PW_AUSKUNFT_MANDANT_17!,
};

const nachzahlungvsservice_Mandant17: User = {
  userName: process.env.UN_NACHZAHLUNGSSERVICE_MANDANT_17!,
  password: process.env.PW_NACHZAHLUNGSSERVICE_MANDANT_17!,
};

const ohne_Rechte_Mandant70: User = {
  userName: process.env.UN_OHNE_RECHTE_MANDANT_70!,
  password: process.env.PW_OHNE_RECHTE_MANDANT_70!,
};

const testnutzer_Mandant70: User = {
  userName: process.env.UN_TESTNUTZER_MANDANT_70!,
  password: process.env.PW_TESTNUTZER_MANDANT_70!,
};

const gateway_Mandant70: User = {
  userName: process.env.UN_GATEWAY_MANDANT_70!,
  password: process.env.PW_GATEWAY_MANDANT_70!,
};

const bereitsteller_Mandant70: User = {
  userName: process.env.UN_BEREITSTELLER_MANDANT_70!,
  password: process.env.PW_BEREITSTELLER_MANDANT_70!,
};

const freigeber_Mandant70: User = {
  userName: process.env.UN_FREIGEBER_MANDANT_70!,
  password: process.env.PW_FREIGEBER_MANDANT_70!,
};

const auskunft_Mandant70: User = {
  userName: process.env.UN_AUSKUNFT_MANDANT_70!,
  password: process.env.PW_AUSKUNFT_MANDANT_70!,
};

const nachzahlungvsservice_Mandant70: User = {
  userName: process.env.UN_NACHZAHLUNGSSERVICE_MANDANT_70!,
  password: process.env.PW_NACHZAHLUNGSSERVICE_MANDANT_70!,
};

const testnutzer_Mandant91: User = {
  userName: process.env.UN_TESTNUTZER_MANDANT_91!,
  password: process.env.PW_TESTNUTZER_MANDANT_91!,
};

const gateway_Mandant91: User = {
  userName: process.env.UN_GATEWAY_MANDANT_91!,
  password: process.env.PW_GATEWAY_MANDANT_91!,
};

const bereitsteller_Mandant91: User = {
  userName: process.env.UN_BEREITSTELLER_MANDANT_91!,
  password: process.env.PW_BEREITSTELLER_MANDANT_91!,
};

const freigeber_Mandant91: User = {
  userName: process.env.UN_FREIGEBER_MANDANT_91!,
  password: process.env.PW_FREIGEBER_MANDANT_91!,
};

const auskunft_Mandant91: User = {
  userName: process.env.UN_AUSKUNFT_MANDANT_91!,
  password: process.env.PW_AUSKUNFT_MANDANT_91!,
};

const nachzahlungvsservice_Mandant91: User = {
  userName: process.env.UN_NACHZAHLUNGSSERVICE_MANDANT_91!,
  password: process.env.PW_NACHZAHLUNGSSERVICE_MANDANT_91!,
};

export const userMap = new Map<string, Map<string, User>>([
  [
    '17',
    new Map<string, User>([
      ['Testnutzer', testnutzer_Mandant17],
      ['Gateway', gateway_Mandant17],
      ['Bereitsteller', bereitsteller_Mandant17],
      ['Freigeber', freigeber_Mandant17],
      ['Auskunft', auskunft_Mandant17],
      ['Nachzahlungsservice', nachzahlungvsservice_Mandant17],
    ]),
  ],
  [
    '70',
    new Map<string, User>([
      ['Testnutzer', testnutzer_Mandant70],
      ['Keiner', ohne_Rechte_Mandant70],
      ['Gateway', gateway_Mandant70],
      ['Bereitsteller', bereitsteller_Mandant70],
      ['Freigeber', freigeber_Mandant70],
      ['Auskunft', auskunft_Mandant70],
      ['Nachzahlungsservice', nachzahlungvsservice_Mandant70],
    ]),
  ],
  [
    '91',
    new Map<string, User>([
      ['Testnutzer', testnutzer_Mandant91],
      ['Gateway', gateway_Mandant91],
      ['Bereitsteller', bereitsteller_Mandant91],
      ['Freigeber', freigeber_Mandant91],
      ['Auskunft', auskunft_Mandant91],
      ['Nachzahlungsservice', nachzahlungvsservice_Mandant91],
    ]),
  ],
]);
export function getUserMap(): Map<string, Map<string, User>> {
  return userMap;
}
