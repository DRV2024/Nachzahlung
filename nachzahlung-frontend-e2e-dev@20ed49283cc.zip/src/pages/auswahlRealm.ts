import { Locator, Page } from '@playwright/test';

export class AuswahlRealmPage {
  readonly page: Page;
  private readonly testNutzerButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.testNutzerButton = page.getByRole('link', { name: 'Testnutzer' });
  }
  public async auswahl() {
    await this.testNutzerButton.click();
  }
}
