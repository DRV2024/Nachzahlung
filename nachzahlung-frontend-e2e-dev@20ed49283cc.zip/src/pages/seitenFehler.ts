// import { LoginPage } from './login';
import { getUiBaseUrl } from '../support/environments';
import { Locator, Page } from '@playwright/test';

export class SeitenFehler {
  readonly page: Page;
  // private readonly loginPage: LoginPage;
  private readonly pageNotFoundTitle: Locator;

  constructor(page: Page) {
    this.page = page;
    // this.loginPage = new LoginPage(this.page);
    this.pageNotFoundTitle = page.locator(
      'body > app-root > div > div > app-page-not-found > div > div > div.drv--blue-background.drv--align-content-center > div > h3',
    );
  }

  public async getPageNotFoundTitle() {
    return await this.pageNotFoundTitle.innerText();
  }

  public async openUngueltigeUrl(nachzahlung_id: string) {
    await this.page.goto(`${getUiBaseUrl()}/nachzahlung/${nachzahlung_id}`);
    // await this.loginPage.login();
  }
}
