import { config } from '../support/config';
import { Locator, Page } from '@playwright/test';

export class ErstattungsanspruchForm {
  readonly page: Page;
  private currentZeitraumIndex = 0;
  private readonly validAdresschlüssel = '000000AS3';
  private readonly validErstattungsberechtigteStelle = 'Jobcenter Göttingen';
  private readonly validAktenzeichen = '123088/0000321';
  private readonly validRvPurNummer = '10101';
  private readonly validErstattungGeltendMachen = 'ja';
  private readonly validRechtsgrundlage = '103';
  private readonly validBuchungszeichen = 'BZ-1111';
  private readonly validStartdatum = '01.04.2022';
  private readonly validEnddatum = '30.04.2022';
  private readonly validBetragForderung = '150,00';
  private readonly rvPurNummer: Locator;
  private readonly aktenzeichen: Locator;
  private readonly ErstattungGeltendMachenTrue: Locator;
  private readonly ErstattungGeltendMachenFalse: Locator;
  private readonly buchungszeichen: Locator;
  private readonly rechtsgrundlage103: Locator;
  private readonly rechtsgrundlage104: Locator;
  private readonly fieldRangfolge: Locator;
  private readonly rangfolge1: Locator;
  private readonly rangfolge2: Locator;
  private readonly rangfolge3: Locator;
  private startdatum: Locator;
  private enddatum: Locator;
  private betragForderung: Locator;
  private zeitraumVonError: Locator;
  private zeitraumBisError: Locator;
  private zeitraumLabel: Locator;
  private readonly saveButton: Locator;
  private readonly cancelButton: Locator;
  private readonly adressschlüssel: Locator;
  private readonly erstattungsBerechtigteStelle: Locator;
  private readonly formErrors: Locator;
  private readonly errorMessage: Locator;
  private readonly errorMessage1: Locator;
  private readonly notificationTitle: Locator;
  private readonly errorMessageAdressschlüssel: Locator;
  private readonly errorMessageErstattungsBerechtigeStelle: Locator;
  private readonly errorMessageAktenzeichen: Locator;
  private readonly errorMessageDokumentNr: Locator;
  private readonly errorMessageStartdatum: Locator;
  private readonly errorMessageEnddatum: Locator;
  private readonly errorMessageBetragForderung: Locator;
  private readonly hinzufügenZeitraum: Locator;
  private readonly forderungManuellLabel: Locator;
  private readonly forderungMaschinellLabel: Locator;
  private readonly forderungMaschinellManuellLabel: Locator;
  private readonly forderungAnspruchManuellIcon: Locator;
  private readonly forderungAnspruchMaschinellIcon: Locator;

  constructor(page: Page) {
    this.page = page;
    this.rvPurNummer = page.locator('#rvPurNummerInput');
    this.aktenzeichen = page.locator('#aktenzeichenInput');
    this.ErstattungGeltendMachenTrue = page.locator('#fehlanzeigeTrue');
    this.ErstattungGeltendMachenTrue = page.locator('label:has-text("Ja")');
    this.ErstattungGeltendMachenFalse = page.locator('label:has-text("Nein")');
    this.buchungszeichen = page.locator('#buchungszeichenInput');
    this.rechtsgrundlage103 = page.getByText('§ 103 SGB X');
    this.rechtsgrundlage104 = page.getByText('§ 104 SGB X');
    this.fieldRangfolge = page.locator('#fieldsetRangfolge');
    this.rangfolge1 = page.getByRole('group', { name: 'Rangfolge optional' }).getByText('1');
    this.rangfolge2 = page.locator('label:has-text("2")');
    this.rangfolge3 = page.getByRole('group', { name: 'Rangfolge optional' }).getByText('3');
    this.startdatum = page.locator('');
    this.enddatum = page.locator('');
    this.betragForderung = page.locator('');
    this.zeitraumVonError = page.locator('');
    this.zeitraumBisError = page.locator('');
    this.zeitraumLabel = page.locator('');
    this.saveButton = page.locator('#saveBtn');
    this.cancelButton = page.locator('#cancelBtn');
    this.notificationTitle = page.locator('.drv-notification__title').nth(0);
    this.adressschlüssel = page.locator('#adressschluesselErstattungsstelleInput');
    this.erstattungsBerechtigteStelle = page.locator('#nameErstattungsstelleInput');
    this.formErrors = page.locator('#aktenzeichenInput-errors');
    this.errorMessageAdressschlüssel = page.locator(
      '#adressschluesselErstattungsstelleInput_errors .drv-field-message__text',
    );
    this.errorMessageErstattungsBerechtigeStelle = page.locator(
      '#nameErstattungsstelleInput_errors .drv-field-message__text',
    );
    this.errorMessageAktenzeichen = page.locator(
      '#aktenzeichenInput_errors .drv-field-message__text',
    );
    this.errorMessageEnddatum = page.locator('#zeitraumBis-0_errors .drv-field-message__text');
    this.errorMessageStartdatum = page.locator('#zeitraumVon-0_errors .drv-field-message__text');
    this.errorMessageBetragForderung = page.locator(
      '#betragForderungInput-0_errors .drv-field-message__text',
    );
    this.errorMessageDokumentNr = page.locator('#rvPurNummerInput_errors .drv-field-message__text');
    this.errorMessage = page.locator('.drv-field-message--error').nth(1);
    this.errorMessage1 = page.locator('.drv-field-message--error').nth(0);
    this.hinzufügenZeitraum = page.locator('#newErstattungsbetragBtn');
    this.forderungManuellLabel = page.locator('#herkunftForderungManuellLabel');
    this.forderungMaschinellLabel = page.locator('#herkunftForderungMaschinellLabel');
    this.forderungMaschinellManuellLabel = page.locator('#herkunftForderungMaschinellManuellLabel');
    this.forderungAnspruchManuellIcon = page.locator('#herkunftForderungAnspruchManuellIcon');
    this.forderungAnspruchMaschinellIcon = page.locator('#herkunftForderungAnspruchMaschinellIcon');
  }

  public async setAdressschlüssel(input: string) {
    await this.page.waitForTimeout(config.timeout.short);

    await this.adressschlüssel.fill('');
    await this.adressschlüssel.fill(input);
  }

  public async setErstattungsBerechtigteStelle(input: string) {
    await this.erstattungsBerechtigteStelle.fill('');
    await this.erstattungsBerechtigteStelle.fill(input);
  }

  public async setRvPurNummer(input: string) {
    await this.rvPurNummer.fill('');
    await this.rvPurNummer.fill(input);
  }

  public async setAktenzeichen(input: string) {
    await this.aktenzeichen.fill('');
    await this.aktenzeichen.fill(input);
  }

  public async setErstattungGeltendMachen(ErstattungGeltendMachen: string) {
    const option = ErstattungGeltendMachen.toLowerCase();
    if (option == 'ja') {
      await this.ErstattungGeltendMachenTrue.check();
    } else if (option == 'nein') {
      await this.ErstattungGeltendMachenFalse.check();
    }
  }
  public async setErstattungGeltendMachenNein() {
    await this.ErstattungGeltendMachenFalse.check();
  }
  public async setErstattungGeltendMachenJa() {
    await this.ErstattungGeltendMachenTrue.check();
  }

  public async setBuchungszeichen(input: string) {
    await this.buchungszeichen.type(input);
  }

  public async setRechtsgrundlage(input: string) {
    if (input === '103') {
      await this.rechtsgrundlage103.check();
    } else if (input === '104') {
      await this.rechtsgrundlage104.check();
    } else if (input === '') {
      //nicht tun, wenn der Eingabewert leer ist
    }
  }
  public async setRechtsgrundlage104() {
    await this.rechtsgrundlage104.check();
  }
  public async setRangfolge1() {
    await this.rangfolge1.check();
  }
  public async setRang(input: string) {
    if (input === '' || input === '1') {
      // keine Aktion erforderlich, da Rangfolge 1 autoamtisch markiert wird.
    } else if (input === '2') {
      await this.rangfolge2.check();
    } else if (input === '3') {
      await this.rangfolge3.check();
    } else {
      throw new Error('Unbekannter Eingabewert');
    }
  }

  public async getfieldRangfolge() {
    return this.fieldRangfolge;
  }
  public async getRang1() {
    return this.rangfolge1;
  }

  public async getRang2() {
    return this.rangfolge2;
  }

  public async getRang3() {
    return this.rangfolge3;
  }

  public async setStartdatum(input: string, currentZeitraumIndex: number) {
    this.startdatum = this.page.locator('#zeitraumVon-' + currentZeitraumIndex);
    await this.startdatum.type(input);
  }

  public async getZeitraumVomError(nth: number) {
    this.zeitraumVonError = this.page.locator('#zeitraumVonError-' + nth);
    return (await this.zeitraumVonError.innerText())?.trim();
  }

  public async setEnddatum(input: string, currentZeitraumIndex: number) {
    this.enddatum = this.page.locator('#zeitraumBis-' + currentZeitraumIndex);
    await this.enddatum.type(input);
  }
  public async getZeitraumBisError(nth: number) {
    this.zeitraumBisError = this.page.locator('#zeitraumBisError-' + nth);
    return (await this.zeitraumBisError.innerText())?.trim();
  }

  public async getZeitraumLabel(nth: number) {
    this.zeitraumLabel = this.page.locator('#zeitraumLabel-' + nth);
    return await this.zeitraumLabel.innerText();
  }
  public async setBetragForderung(input: string, nth: number) {
    this.betragForderung = this.page.locator('#betragForderungInput-' + nth);
    await this.betragForderung.fill(input);
  }

  public async skipForwardModal() {
    let num = 1;
    for (num = 1; num <= 16; num++) {
      await this.page.keyboard.press('Tab');
    }
  }

  public async skipBackwardModal() {
    let num = 1;
    for (num = 1; num <= 3; num++) {
      await this.page.keyboard.press('Shift+Tab');
    }
  }
  public async pressEnter() {
    await this.page.keyboard.press('Enter');
  }

  public async saveForderung() {
    await this.saveButton.click({ force: true });
    await this.page.waitForTimeout(config.timeout.short);
  }

  public async clickCancel() {
    await this.cancelButton.click();
    await this.page.waitForTimeout(config.timeout.short);
  }

  public async fillForderungValid() {
    await this.setAdressschlüssel(this.validAdresschlüssel);
    await this.setErstattungsBerechtigteStelle(this.validErstattungsberechtigteStelle);
    await this.setRvPurNummer(this.validRvPurNummer);
    await this.setAktenzeichen(this.validAktenzeichen);
    await this.setErstattungGeltendMachen(this.validErstattungGeltendMachen);
    await this.setBuchungszeichen(this.validBuchungszeichen);
    await this.setRechtsgrundlage(this.validRechtsgrundlage);
    await this.setStartdatum(this.validStartdatum, 0);
    await this.setEnddatum(this.validEnddatum, 0);
    await this.setBetragForderung(this.validBetragForderung, 0);
  }
  public async clearFields() {
    await this.page.waitForTimeout(config.timeout.short);
    await this.buchungszeichen.fill('');
    await this.adressschlüssel.fill('');
    await this.erstattungsBerechtigteStelle.fill('');
    await this.rvPurNummer.fill('');
    await this.aktenzeichen.fill('');
  }
  public async fillForderung(
    Adressschlüssel: string,
    ErstattungsBerechtigteStelle: string,
    RvPurNummer: string,
    Aktenzeichen: string,
    ErstattungGeltendMachen: string,
    Buchungszeichen: string,
    Rechtsgrundlage: string,
    Startdatum: string,
    Enddatum: string,
    BetragForderung: string,
    Rangfolge: string,
  ) {
    await this.setAdressschlüssel(Adressschlüssel);
    await this.setErstattungsBerechtigteStelle(ErstattungsBerechtigteStelle);
    await this.setRvPurNummer(RvPurNummer);
    await this.setAktenzeichen(Aktenzeichen);
    await this.setErstattungGeltendMachen(ErstattungGeltendMachen);
    await this.setBuchungszeichen(Buchungszeichen);
    await this.setRechtsgrundlage(Rechtsgrundlage);
    await this.setRang(Rangfolge);
    if (ErstattungGeltendMachen === 'ja') {
      await this.setStartdatum(Startdatum, 0);
      await this.setEnddatum(Enddatum, 0);
      await this.setBetragForderung(BetragForderung, 0);
    }
  }
  public async fillForderungErstattungGeltendMachenNein(
    Adressschlüssel: string,
    ErstattungsBerechtigteStelle: string,
    RvPurNummer: string,
    Aktenzeichen: string,
    ErstattungGeltendMachen: string,
  ) {
    await this.setAdressschlüssel(Adressschlüssel);
    await this.setErstattungsBerechtigteStelle(ErstattungsBerechtigteStelle);
    await this.setRvPurNummer(RvPurNummer);
    await this.setAktenzeichen(Aktenzeichen);
    await this.setErstattungGeltendMachen(ErstattungGeltendMachen);
  }
  // Ein Array, um alle Zeiträume zu speichern
  private zeitRaumListe: Array<{ startdatum: string; enddatum: string; betragForderung: string }> =
    [];

  public async fillZeitraum(
    zeitRaumNummer: number,
    Startdatum: string,
    Enddatum: string,
    BetragForderung: string,
  ) {
    this.currentZeitraumIndex = zeitRaumNummer - 1;
    await this.setStartdatum(Startdatum, this.currentZeitraumIndex);
    await this.setEnddatum(Enddatum, this.currentZeitraumIndex);
    await this.setBetragForderung(BetragForderung, this.currentZeitraumIndex);
    this.zeitRaumListe.push({
      startdatum: Startdatum,
      enddatum: Enddatum,
      betragForderung: BetragForderung,
    });
  }

  public async getFehlermeldung() {
    return (await this.formErrors.textContent())?.trim();
  }

  public async getNotificationTitle() {
    return (await this.notificationTitle.innerText())?.trim();
  }

  public async getErrorMessageAdressschlüssel() {
    return (await this.errorMessageAdressschlüssel.innerText())?.trim();
  }

  public async getErrorMessageErstattungsBerechtigteStelle() {
    return (await this.errorMessageErstattungsBerechtigeStelle.innerText())?.trim();
  }

  public async getErrorMessageAktenzeichen() {
    return (await this.errorMessageAktenzeichen.innerText())?.trim();
  }

  public async getErrorMessageDokumentNr() {
    return (await this.errorMessageDokumentNr.innerText())?.trim();
  }

  public async getErrorMessageStartdatum() {
    return (await this.errorMessageStartdatum.innerText())?.trim();
  }

  public async getErrorMessageEnddatum() {
    return (await this.errorMessageEnddatum.innerText())?.trim();
  }

  public async getErrorMessageBetragForderung() {
    return (await this.errorMessageBetragForderung.innerText())?.trim();
  }

  public async getErrorMessage() {
    return (await this.errorMessage.innerText())?.trim();
  }

  public async getErrorMessage1() {
    return (await this.errorMessage1.innerText())?.trim();
  }

  public async deleteZeitraum(nr: number) {
    await this.page.locator('#zeitraumDeleteBtn-' + (nr - 1)).click();
  }

  public async addZeitraum() {
    await this.hinzufügenZeitraum.click();
  }

  public async getAdresschlüssel() {
    return await this.adressschlüssel.inputValue();
  }

  public async getErstattungsstelle() {
    return await this.erstattungsBerechtigteStelle.inputValue();
  }

  public async getAktenzeichen() {
    return await this.aktenzeichen.inputValue();
  }

  public async getBuchungszeichen() {
    return await this.buchungszeichen.inputValue();
  }

  public async getEnddatum() {
    return await this.enddatum.inputValue();
  }

  public async getForderungManuellLabel() {
    return (await this.forderungManuellLabel.innerText())?.trim();
  }

  public async getForderungMaschinellLabel() {
    return (await this.forderungMaschinellLabel.innerText())?.trim();
  }

  public async getForderungMaschinellManuellLabel() {
    return (await this.forderungMaschinellManuellLabel.innerText())?.trim();
  }

  public async getForderungAnspruchManuellIcon() {
    return this.forderungAnspruchManuellIcon;
  }

  public async getForderungAnspruchMaschinellIcon() {
    return this.forderungAnspruchMaschinellIcon;
  }

  public async getValidErstattungsstelle() {
    return this.validErstattungsberechtigteStelle;
  }
}
