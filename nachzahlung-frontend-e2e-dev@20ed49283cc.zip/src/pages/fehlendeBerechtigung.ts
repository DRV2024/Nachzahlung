import { config } from '../support/config';
import { Locator, Page } from '@playwright/test';

export class FehlendeBerichtigungPage {
  readonly page: Page;
  private readonly fehlendeBerechtigungText: Locator;

  constructor(page: Page) {
    this.page = page;
    this.fehlendeBerechtigungText = page.getByRole('heading', { name: 'Fehlende Berechtigung' });
  }
  public async getfehlendeBerichtigungText() {
    await this.page.waitForTimeout(config.timeout.short);
    return await this.fehlendeBerechtigungText.innerText();
  }
}
