import { Locator, Page } from '@playwright/test';

export class VerzinsungUebersicht {
  readonly page: Page;
  private readonly verzinsungsUebersichtsTitle: Locator;
  private readonly verzinsungsTitle: Locator;
  private readonly abschlussText: Locator;
  private readonly zinsenSumme: Locator;
  private readonly antragsEingangsDatum: Locator;
  private readonly zinsenSummary: Locator;
  private readonly verzinsungNichtVorgenommen: Locator;

  constructor(page: Page) {
    this.page = page;
    this.verzinsungsUebersichtsTitle = page.locator('#nachzahlungUebersichtTitleH1');
    this.verzinsungsTitle = page.locator('#nachzahlungTitleH1');
    this.abschlussText = page.locator('#abschlussText');
    this.zinsenSumme = page.locator('#zinsenSumme');
    this.antragsEingangsDatum = page.locator('#eingangRentenantrag');
    this.zinsenSummary = page.locator('summary.accordion-item');
    this.verzinsungNichtVorgenommen = page.locator('#verzinsungNichtVorgenommen');
  }

  public async getVerzinsungsUebersichtTitle() {
    return await this.verzinsungsUebersichtsTitle.innerText();
  }

  public async getVerzinsungsTitle() {
    return await this.verzinsungsTitle.innerText();
  }

  public async getZinsenText() {
    return await this.abschlussText.innerText();
  }

  public async getAbschlussText() {
    return await this.abschlussText.innerText();
  }

  public async getZinsenSumme() {
    return (await this.zinsenSumme.innerText())?.replace('€', '').trim().replaceAll('.', '');
  }
  // public async getZinsWert(nr: number) {
  // return await this.page
  //   .locator('#textErstattungHinweis-accordionItem-zinsen-' + (nr - 1))
  //   .innerText();
  // }

  public async getZinsWert(zinsMonatJahr: string): Promise<string> {
    const row = this.page.locator('tr', {
      has: this.page.locator(`td[data-label="Zinsmonat"]:has-text("${zinsMonatJahr}")`),
    });
    return (await row.locator('td[data-label="Kalkulierte Zinsen"]').innerText())
      .replace('€', '')
      .trim();
  }

  // public async getZinsMonatJahr(nr: number) {
  // Dies selektiert das Element, das den Monat und das Jahr der Zinsen darstellt
  // return await this.page.locator('#titleSummary-accordionItem-zinsen-' + (nr - 1)).innerText();
  // }
  public async getZinsMonatJahr(zinsMonatJahr: string): Promise<string> {
    const row = this.page.locator('tr', {
      has: this.page.locator(`td[data-label="Zinsmonat"]:has-text("${zinsMonatJahr}")`),
    });
    return await row.locator('td[data-label="Zinsmonat"]').innerText();
  }
  public async getVerzinsungNichtVorgenommenText() {
    return await this.verzinsungNichtVorgenommen.innerText();
  }

  public async getZeilenAnzahl() {
    return await this.zinsenSummary.count();
  }
  public async setAntragsEingangsDatum(input: string) {
    await this.antragsEingangsDatum.type(input);
  }
}
