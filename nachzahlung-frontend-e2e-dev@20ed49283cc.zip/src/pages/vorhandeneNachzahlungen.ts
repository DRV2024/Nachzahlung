// import { LoginPage } from './login';
import { AuswahlRealmPage } from './auswahlRealm';
import { getUiBaseUrl } from '../support/environments';
import { getBestandsToken } from '../steps/general.steps';
import { Locator, Page } from '@playwright/test';
// import { getBestandsToken } from '../steps/general.steps';

export class VorhandeneNachzahlungen {
  readonly page: Page;
  // private readonly loginPage: LoginPage;
  private readonly auswahlRealmPage: AuswahlRealmPage;
  private readonly nachzahlungsUebersichtsTitle: Locator;
  //private readonly ersteNachzahlung: Locator;
  //private readonly bescheidDatumErsteNachzahlung: Locator;
  //private readonly zweiteNachzahlung: Locator;
  //private readonly bescheidDatumZweiteNachzahlung: Locator;
  //constructor(page: Page) {
  constructor(page: Page, auswahlRealmPage: AuswahlRealmPage) {
    this.page = page;
    // this.loginPage = loginPage;
    this.auswahlRealmPage = auswahlRealmPage;
    this.nachzahlungsUebersichtsTitle = page.locator('#nachzahlungUebersichtTitleH1');
    //this.ersteNachzahlung = page.locator('#nachzahlungUebersichtLeistungsartName-0');
    //this.zweiteNachzahlung = page.locator('#nachzahlungUebersichtLeistungsartName-1');
    //this.bescheidDatumErsteNachzahlung = page.locator('#nachzahlungUebersichtBescheiddatum-0');
    //this.bescheidDatumZweiteNachzahlung = page.locator('#nachzahlungUebersichtBescheiddatum-1');
  }
  //Die Methode textContent wid verwendet um den Textinhalt des elements zu erhalten.
  // Die Funktion gibt entweder den Textinhalt als Zeichenkette oder null, wenn das element nicht gefunden werden kann
  //public async getErsteNachzahlung(): Promise<string | null> {
  //  return this.ersteNachzahlung.textContent();
  //}
  //public async getZweiteNachzahlung(): Promise<string | null> {
  //  return this.zweiteNachzahlung.textContent();
  //}
  //public async getDatumErsteNachzahlung(): Promise<string | null> {
  //  return this.bescheidDatumErsteNachzahlung.textContent();
  //}
  //public async getDatumZweiteNachzahlung(): Promise<string | null> {
  //  return this.bescheidDatumZweiteNachzahlung.textContent();
  //}
  //(await this.errorMessage.innerText())?.trim()
  //public async getErsteNachzahlung() {
  //  return await this.ersteNachzahlung.innerText();
  //}
  //public async getZweiteNachzahlung() {
  //  return await this.zweiteNachzahlung.innerText();
  //}
  //public async getDatumErsteNachzahlung() {
  //  return await this.bescheidDatumErsteNachzahlung.innerText();
  //}
  //public async getDatumZweiteNachzahlung() {
  //  return await this.bescheidDatumZweiteNachzahlung.innerText();
  //}

  public async öffneVorhandeneNachzahlung(nr: number, vorgangsId: string) {
    await this.page.locator('#id-' + vorgangsId + '-' + (nr - 1)).click();
  }
  public async openNachzahlungsübersicht(VSNR: string) {
    await this.page.goto(
      `${getUiBaseUrl()}/nzv/nachzahlungen/?vsnr=${VSNR}&rvdialog_token=${getBestandsToken()}`,
    );
    await this.auswahlRealmPage.auswahl();
  }
  public async openAnspruchsseite(vorgangsId: string) {
    await this.page.goto(
      `${getUiBaseUrl()}/nzv/nachzahlungen/${vorgangsId}?rvdialog_token=${getBestandsToken()}`,
    );
    await this.auswahlRealmPage.auswahl();
  }
  public async selectNachzahlung(nr: number) {
    await this.page.locator('#nachzahlungUebersichtLeistungsartName-' + (nr - 1)).click();
  }

  public async getNachzahlungUebersichtTitle() {
    return await this.nachzahlungsUebersichtsTitle.innerText();
  }
  public async getNachzahlungUebersichtRentenberechtigtePerson(nr: number) {
    return await this.page
      .locator(`#nachzahlungUebersichtRentenberechtigtePerson-${nr}`)
      .innerText();
  }
  public async getLeistungsart(nr: number) {
    return await this.page
      .locator('#nachzahlungUebersichtLeistungsartName-' + (nr - 1))
      .innerText();
  }

  public async getBescheiddatum(nr: number) {
    return await this.page.locator('#nachzahlungUebersichtBescheiddatum-' + (nr - 1)).textContent();
  }
}
