import { Locator, Page } from '@playwright/test';

export class AntragEingang {
  readonly page: Page;
  private readonly antragEingangInput: Locator;
  private readonly antragEingangError: Locator;

  constructor(page: Page) {
    this.page = page;
    this.antragEingangInput = page.locator('#antragEingangInput');
    this.antragEingangError = page.locator('#antragEingangError');
  }

  public async setAntragEingangDatum(input: string) {
    await this.antragEingangInput.type(input);
  }

  public async getAntragsDatum() {
    await this.page.locator(
      'body > app-root > div > div > app-main > app-nachzahlung > div > app-antragsdatum-aenderung > div > p:nth-child(4) > b',
    );
  }

  public async getAntragEingangError() {
    return await this.antragEingangError.innerText();
  }
}
