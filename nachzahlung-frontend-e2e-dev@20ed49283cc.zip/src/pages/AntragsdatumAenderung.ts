import { Locator, Page } from '@playwright/test';

export class AntragsdatumÄnderung {
  readonly page: Page;
  private readonly eingangRentenantrag: Locator;

  constructor(page: Page) {
    this.page = page;
    this.eingangRentenantrag = page.locator('#eingangRentenantrag');
  }

  public async getEingangRentenantrag() {
    return await this.eingangRentenantrag.innerText();
  }

  public async setRentenantragsdatum(input: string) {
    await this.eingangRentenantrag.type(input);
  }
}
