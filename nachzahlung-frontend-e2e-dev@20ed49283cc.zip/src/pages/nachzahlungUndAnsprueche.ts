import { config } from '../support/config';
import { Locator, Page } from '@playwright/test';

export class NachzahlungUndAnsprüche {
  readonly page: Page;
  // private readonly loginPage: LoginPage;
  private readonly deleteModal: Locator;
  private readonly hinzufügenErstattungsanspruch: Locator;
  private readonly nachzahlungsTitle: Locator;
  private readonly nachzahlungsZeitraum: Locator;
  private readonly leistungsart: Locator;
  private readonly bescheidDatum: Locator;
  private readonly nachzahlungsBetrag: Locator;
  private readonly restbetrag: Locator;
  private readonly versicherterName: Locator;
  // private readonly versicherterVorname: Locator;
  private readonly rentenBerechtigtePerson: Locator;
  private readonly meldungKeinRestbetrag: Locator;

  constructor(page: Page) {
    this.page = page;
    this.deleteModal = page.locator('#deleteModalDeleteBtn');
    this.hinzufügenErstattungsanspruch = page.locator('#addErstattungsanspruchBtn');
    this.nachzahlungsTitle = page.locator('#nachzahlungTitleH1');
    this.nachzahlungsZeitraum = page.locator('#nachzahlungZeitraumDerNachzahlung');
    this.leistungsart = page.locator('#nachzahlungLeistungsart');
    this.bescheidDatum = page.locator('#nachzahlungBescheiddatum');
    this.nachzahlungsBetrag = page.locator('#nachzahlungHoeheDerRentennachzahlung');
    this.restbetrag = page.locator('#nachzahlungRestbetrag2');
    this.versicherterName = page.locator('.drv-application-header__subtitle');
    this.meldungKeinRestbetrag = page.getByText(
      'Es steht kein Restbetrag zur Verfügung, daher ist eine Verzinsung nicht durchzuführen.',
    );
    // this.rentenBerechtigtePerson = page.locator('#nachzahlungRentenberechtigtePerson');
    this.rentenBerechtigtePerson = page.getByText('Rentenberechtigte Person').locator('.. >> dd');
  }
  public async getVersicherterName(): Promise<string> {
    const textContent = await this.versicherterName.textContent();
    const textValue = textContent?.slice(2);
    return textValue || ''; // Rückgabewert ist niemals null
  }

  public async getRentenBerechtigePersonName(): Promise<string> {
    const textContent = await this.rentenBerechtigtePerson.textContent();
    const splitTextContent = textContent?.split(',');
    return splitTextContent![0] || ''; // Rückgabewert ist niemals null
  }
  public async getRentenBerechtigePersonVorname(): Promise<string> {
    const textContent = await this.rentenBerechtigtePerson.textContent();
    const splitTextContent = textContent?.split(',');
    return splitTextContent![1] || ''; // Rückgabewert ist niemals null
  }
  public async editAnspruch(param: string) {
    await this.page.locator('#accordionItem-' + param + '-edit').click();
  }

  public async deleteErstattungsstelle(param: string) {
    await this.page.waitForTimeout(config.timeout.short);
    await this.page.locator('#accordionItem-' + param + '-delete').click();
  }
  public async öffneErstattungsstelle(param: string) {
    await this.page.locator('#accordionItem-' + param).click();
  }

  public async öffneZinsAccordion(nr: number) {
    await this.page.locator('#accordionItem-zinsen-' + (nr - 1)).click();
  }

  public async deleteConfirm() {
    await this.page.waitForSelector('#deleteModalDeleteBtn');
    await this.deleteModal.click({ force: true });
    await this.page.waitForTimeout(config.timeout.short);
  }
  public async addErstattungsanspruch() {
    await this.page.waitForSelector('#addErstattungsanspruchBtn', {
      timeout: config.timeout.long,
    });
    await this.hinzufügenErstattungsanspruch.click();
  }

  public async getForderungAnspruchManuellIconTabelle(nr: number) {
    return this.page.locator('#accordionItem-' + (nr - 1) + '-manuell-icon');
  }

  public async getForderungAnspruchMaschinellIconTabelle(nr: number) {
    return this.page.locator('#accordionItem-' + (nr - 1) + '-maschinell-icon');
  }

  public async getErstattungsstelleName(nr: number) {
    return (await this.page.locator('#accordionItem-' + (nr - 1) + '-name').innerText()).trim();
  }

  public async getNachzahlungTitle() {
    return await this.nachzahlungsTitle.innerText();
  }
  public async getMeldungKeinRestBetrag() {
    return await this.meldungKeinRestbetrag.innerText();
  }
  public async getSummeAnsprüche() {
    return (await this.page.locator('#summeWert').innerText()).replace('€', '').trim();
  }

  public async getSummeRestbetrag() {
    return (await this.restbetrag.innerText()).replace('€', '').trim();
  }

  public async getErstattungsanspruchsbetrag(eintragNummer: number, adressschluessel: string) {
    const locator = this.page.locator(`[id="${adressschluessel}-${eintragNummer}-betrag"]`);
    const betrag = await locator.innerText();
    await this.page.waitForTimeout(config.timeout.medium);
    return betrag.replace('€', '').trim();
  }

  public async getRangfolgeFehlerhaft(param: string) {
    const rangfolgeFehlerhaft = this.page.locator('#textErstattungHinweis-accordionItem-' + param);
    return (await rangfolgeFehlerhaft.innerText()).trim();
  }
  public async getHinweisKeinAnspruchGeltendGemacht(param: string) {
    const hinweisKeinAnspruchGeltendGemacht = this.page.locator(
      '#textErstattungHinweis-accordionItem-' + param,
    );
    return (await hinweisKeinAnspruchGeltendGemacht.innerText()).trim();
  }
  public async getTextErstattungHinweis(param: string) {
    const textErstattungHinweisAntwortAusstehend = this.page.locator(
      '#textErstattungHinweis-accordionItem-' + param,
    );
    return (await textErstattungHinweisAntwortAusstehend.innerText()).trim();
  }
  public async getNachzahlungsZeitraum() {
    const text = await this.nachzahlungsZeitraum.innerText();
    return Number(text);
  }

  public async getLeistungsart() {
    return await this.leistungsart.innerText();
  }

  public async getBescheidDatum() {
    return await this.bescheidDatum.innerText();
  }

  public async getNachzahlungsBetrag() {
    return (await this.nachzahlungsBetrag.innerText()).replace('€', '').trim();
  }
}
