import { Locator, Page } from '@playwright/test';
import { setTimeout } from 'timers/promises';

export class VersichertenHeader {
  readonly page: Page;
  private readonly versicherterVSNR: Locator;
  private readonly versicherterName: Locator;
  private readonly versicherterVorname: Locator;

  constructor(page: Page) {
    this.page = page;
    this.versicherterVSNR = page.locator('#versicherterVSNR');
    this.versicherterName = page.locator('#versicherterName');
    this.versicherterVorname = page.locator('#versicherterVorname');
  }

  private async waitForVersichertenDaten() {
    while ((await this.versicherterVSNR.innerText()) == '') {
      await setTimeout(50);
    }
  }

  public async getVersicherterVSNR() {
    await this.waitForVersichertenDaten();
    return await this.versicherterVSNR.innerText();
  }

  public async getVersicherterName() {
    await this.waitForVersichertenDaten();
    return await this.versicherterName.innerText();
  }

  public async getVersicherterVorname() {
    await this.waitForVersichertenDaten();
    return await this.versicherterVorname.innerText();
  }
}
