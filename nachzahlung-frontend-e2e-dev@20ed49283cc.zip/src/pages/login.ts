import { userMap } from '../support/users';
import { Locator, Page } from '@playwright/test';

export class LoginPage {
  readonly page: Page;
  private readonly username: Locator;
  private readonly password: Locator;
  private readonly loginButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.username = page.locator('#username');
    this.password = page.locator('#password');
    this.loginButton = page.locator('#kc-login');
  }
  public async login(mandant: string, userType: string): Promise<void> {
    if (userMap.has(mandant) && userMap.get(mandant)!.has(userType)) {
      const user = userMap.get(mandant)!.get(userType)!;
      await this.username.fill(user.userName);
      await this.password.fill(user.password);
      await this.loginButton.click();
    } else {
      throw new Error(
        `Keine Anmeldedaten für den Benutzertyp "${userType}" und Mandant "${mandant}" gefunden.`,
      );
    }
  }
}
