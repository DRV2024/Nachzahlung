import { config } from '../support/config';
import { Locator, Page } from '@playwright/test';

export class Navigation {
  readonly page: Page;
  private readonly abschlussBtn: Locator;
  private readonly abrechneBtn: Locator;
  private readonly abrechneAnzeigeBtn: Locator;
  private readonly verzinsungBtn: Locator;
  private readonly zurueckBtn: Locator;
  private readonly antragsdatumaendern: Locator;

  constructor(page: Page) {
    this.page = page;
    this.abschlussBtn = page.locator('#abschlussBtn');
    this.abrechneAnzeigeBtn = page.locator('#AbrechnungAnzeigenBtn');
    this.abrechneBtn = page.locator('#abrechnenBtn');
    this.verzinsungBtn = page.locator('#verzinsungBtn');
    this.zurueckBtn = page.locator('#zurueckBtn');
    this.antragsdatumaendern = page.locator('#antragsdatumAendernBtn');
  }
  public async schliesseBearbeitung() {
    await this.abrechneBtn.click();
  }

  public async schliesseVerzinsung() {
    await this.abschlussBtn.click();
  }
  public async navigateToVerzinsung() {
    try {
      await this.antragsdatumaendern.waitFor({ timeout: config.timeout.long });
      await this.antragsdatumaendern.click();
    } catch (error) {
      await this.verzinsungBtn.waitFor({ timeout: config.timeout.long });
      await this.verzinsungBtn.click();
    }
  }
  public async showAbrechnung() {
    await this.abrechneAnzeigeBtn.click();
  }

  public async navigateToUebersicht() {
    await this.zurueckBtn.click();
  }

  public async getAbschlussBtn() {
    return await this.abschlussBtn.innerText();
  }

  public async getVerzinsungsBtn() {
    return await this.verzinsungBtn.innerText();
  }

  public async getAbrechneBtn() {
    return await this.abrechneAnzeigeBtn.innerText();
  }
  public async getZurueckBtn() {
    return await this.zurueckBtn.innerText();
  }
}
