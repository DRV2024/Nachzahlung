export function getLastVerzinsungsmonat(date: Date): string {
  const fourteenDaysLater = new Date(date.getTime() + 14 * 24 * 60 * 60 * 1000);

  if (fourteenDaysLater.getMonth() === date.getMonth()) {
    date.setMonth(date.getMonth() - 1);
  }

  const monthNames = [
    'Januar',
    'Februar',
    'März',
    'April',
    'Mai',
    'Juni',
    'Juli',
    'August',
    'September',
    'Oktober',
    'November',
    'Dezember',
  ];

  return `${monthNames[date.getMonth()]} ${date.getFullYear()}`;
}

export function isBeforeOrSame(zinsMonatJahr: string, lastVerzinsungsmonat: string): boolean {
  const [monthName1, year1] = zinsMonatJahr.split(' ');
  const [monthName2, year2] = lastVerzinsungsmonat.split(' ');

  const monthNames = [
    'Januar',
    'Februar',
    'März',
    'April',
    'Mai',
    'Juni',
    'Juli',
    'August',
    'September',
    'Oktober',
    'November',
    'Dezember',
  ];

  const month1 = monthNames.indexOf(monthName1);
  const month2 = monthNames.indexOf(monthName2);

  if (parseInt(year1) < parseInt(year2)) return true;
  if (parseInt(year1) > parseInt(year2)) return false;
  return month1 <= month2;
}

export interface Zinswert {
  zinsMonatJahr: string;
  zins: string;
}

export interface ZinsenData {
  zinswerte: Zinswert[];
  summe: string;
}
