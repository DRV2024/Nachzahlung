import { ICustomWorld } from '../support/custom-world';
import { getLastVerzinsungsmonat, isBeforeOrSame, ZinsenData } from '../util/dateUtils';
import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import * as fs from 'fs';
import path from 'path';
Then(
  'die Summe der Zinsen beträgt {} Euro',
  async function (this: ICustomWorld, zinsenSumme: string) {
    await expect(await this.verzinsungsUebersicht?.getZinsenSumme()).toEqual(zinsenSumme);
  },
);
Then(
  'erwartet die Sachbearbeitung die korrekten berechneten Zinsen für {}',
  async function (this: ICustomWorld, testFall: string) {
    if (!this.page) {
      throw new Error('Page is not defined');
    }

    const filePath = path.resolve(__dirname, `../data/${testFall}_zinsen.json`);
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${filePath}`);
    }
    const zinsenData: ZinsenData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    //  das aktuelle Datum als Tagestesting-Datum
    const tagesTestingDate = new Date();
    const lastVerzinsungsmonat = getLastVerzinsungsmonat(tagesTestingDate);

    for (const { zinsMonatJahr, zins } of zinsenData.zinswerte) {
      if (!isBeforeOrSame(zinsMonatJahr, lastVerzinsungsmonat)) {
        continue;
      }

      const row = this.page.locator('tr', {
        has: this.page.locator(`td[data-label="Zinsmonat"]:has-text("${zinsMonatJahr}")`),
      });

      const zinsMonatJahrText = await row.locator('td[data-label="Zinsmonat"]').innerText();
      const zinsenText = (await row.locator('td[data-label="Kalkulierte Zinsen"]').innerText())
        .replace('€', '')
        .trim();

      try {
        expect(zinsMonatJahrText.trim()).toContain(zinsMonatJahr);
        expect(zinsenText).toEqual(zins);
      } catch (error) {
        throw new Error(
          `Fehler bei ${zinsMonatJahr}: Erwartet ${zins}, aber erhalten ${zinsenText}`,
        );
      }
    }
  },
);

When('öffnet sich die Erfolgsseite', async function (this: ICustomWorld) {
  await expect(await this.verzinsungsUebersicht?.getAbschlussText()).toEqual(
    'Durch den Aufruf eines Verfahrenskontenspiegels in rvDialog werden die Daten ins Versicherungskonto übernommen.',
  );
});
When(
  'die Sachbearbeitung gibt den {} Antragseingang ein',
  async function (this: ICustomWorld, antragseingangsDatum: string) {
    await this.verzinsungsUebersicht?.setAntragsEingangsDatum(antragseingangsDatum);
  },
);

Then('erwarte ich die Meldung - {}', async function (this: ICustomWorld, meldungText: string) {
  const page = this.page!;
  const abschlussText = await page
    .locator(
      'body > app-root > div > div > app-main > app-nachzahlung > app-nachzahlung-verzinsung-abschluss > div.drv-bg--ui-02 > div > div > div > div.drv-richtext > p:nth-child(2)',
    )
    .innerText();
  await expect(abschlussText).toEqual(meldungText);
  await expect(page.locator('#abschlussBtn')).toBeEnabled();
});

Then(
  'erwarte ich den Abschlusstext: {}',
  async function (this: ICustomWorld, abschlusstext: string) {
    await expect(await this.verzinsungsUebersicht?.getAbschlussText()).toEqual(abschlusstext);
  },
);

Then(
  'wird die Sachbearbeitung den Hinweis "{}" sehen',
  async function (this: ICustomWorld, hinweistext: string) {
    expect(await this.verzinsungsUebersicht?.getVerzinsungNichtVorgenommenText()).toEqual(
      hinweistext,
    );
  },
);
Then(
  'erwartet die Sachbearbeitung die korrekte Summe der berechneten Zinsen für {}',
  async function (this: ICustomWorld, testFall: string) {
    if (!this.page) {
      throw new Error('Page is not defined');
    }

    const filePath = path.resolve(__dirname, `../data/${testFall}_zinsen.json`);
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${filePath}`);
    }
    const zinsenData: ZinsenData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    //  das aktuelle Datum als Tagestesting-Datum
    const tagesTestingDate = new Date();
    const lastVerzinsungsmonat = getLastVerzinsungsmonat(tagesTestingDate);

    const summe = zinsenData.zinswerte
      .filter(({ zinsMonatJahr }) => isBeforeOrSame(zinsMonatJahr, lastVerzinsungsmonat))
      .reduce((acc, { zins }) => acc + parseFloat(zins.replace(',', '.')), 0);

    const summeText = await this.page.locator('#zinsenSumme').innerText();
    expect(summeText.replace('€', '').trim()).toEqual(summe.toFixed(2).replace('.', ','));
  },
);
