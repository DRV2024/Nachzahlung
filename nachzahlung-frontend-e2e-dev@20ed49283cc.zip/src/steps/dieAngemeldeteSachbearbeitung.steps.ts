/* eslint-disable indent */
/* eslint-disable prettier/prettier */
// eslint-disable-next-line import/no-unresolved
import { ICustomWorld } from '../support/custom-world';
import { Given } from '@cucumber/cucumber';
import { existsSync, readFileSync } from 'fs';
Given('die angemeldete Sachbearbeitung', async function (this: ICustomWorld) {
  const url = 'https://mvp-nzv-frontend-demo.apps.os-evo.entw.bund.drv';
  const authFile = 'playwright/.auth/sachbearbeitung.json';
  let storageState;
  // Überprüfen, ob die JSON-Datei existiert und nicht leer ist
  if (existsSync(authFile)) {
    try {
      const fileContent = readFileSync(authFile, 'utf-8').trim();
      if (fileContent !== '') {
        storageState = JSON.parse(fileContent);
      }
    } catch (error) {
      console.error('Fehler beim Lesen oder Parsen der JSON-Datei:', error);
    }
  }

  if (storageState) {
    // Zustand wiederherstellen
    console.log(
      `<<<<<<<----------------restoring storage state from ${authFile} ------------>>>>>>>>>>>>>`,
    );
    await this.setStorageState(storageState);
    //this.page = await this.context?.newPage();
    //await this.page?.setViewportSize({ width: 1920, height: 1080 });
    //await this.page?.goto(`${url}/nachzahlungen?versicherter_guid=0116`);
  } else {
    // Anmeldung
    await this.page?.goto(url);
    // await this.loginPage?.login();

    // Speichern des StorageState
    await this.saveStorageState(authFile);
    await this.page?.waitForLoadState('load');
  }

  // Navigation zur Nachzahlungsübersicht
  //await this.page?.goto(`${url}/nachzahlungen?versicherter_guid=0116`);
});
