import { ICustomWorld } from '../support/custom-world';
import { Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Then('erwarte ich die Meldung "{}"', async function (this: ICustomWorld, meldungText: string) {
  const page = this.page!;
  const abschlussText = await page
    .locator(
      'body > app-root > div > div > app-main > app-nachzahlung > app-nachzahlung-verzinsung-abschluss > div.drv-bg--ui-02 > div > div > div > div.drv-richtext > p:nth-child(2)',
    )
    .innerText();
  await expect(abschlussText).toEqual(meldungText);
  await expect(page.locator('#abschlussBtn')).toBeEnabled();
});
