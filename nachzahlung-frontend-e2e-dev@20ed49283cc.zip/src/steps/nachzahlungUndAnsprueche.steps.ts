/* eslint-disable no-unused-labels */
import { ICustomWorld } from '../support/custom-world';
import { config } from '../support/config';
import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { setTimeout } from 'timers/promises';

Given(
  'als Zeitraum der Nachzahlung {}, als Leistungsart {}, als Bescheiddatum {} und als Höhe der Rentennachzahlung {} Euro',
  async function (
    this: ICustomWorld,
    nachzahlungsZeitraum: string,
    leistungsart: string,
    bescheidDatum: string,
    nachzahlungsBetrag: string,
  ) {
    expect(await this.nachzahlungUndAnsprüche?.getNachzahlungsZeitraum()).toEqual(
      nachzahlungsZeitraum,
    );
    expect(await this.nachzahlungUndAnsprüche?.getLeistungsart()).toEqual(leistungsart);
    expect(await this.nachzahlungUndAnsprüche?.getBescheidDatum()).toEqual(bescheidDatum);
    expect(await this.nachzahlungUndAnsprüche?.getNachzahlungsBetrag()).toEqual(nachzahlungsBetrag);
  },
);
When(
  'die Sachbearbeitung öffnet den Eintrag {} in der Tabelle',
  async function (this: ICustomWorld, param: string) {
    await this.nachzahlungUndAnsprüche?.öffneErstattungsstelle(param);
  },
);
When(
  'die Sachbearbeitung öffnet in der Zins-Seite den Eintrag Nr. {} in der Tabelle',
  async function (this: ICustomWorld, param: string) {
    const nummer: number = +param;
    await this.nachzahlungUndAnsprüche?.öffneZinsAccordion(nummer);
  },
);
When(
  'die Sachbearbeitung die Bearbeitungsoption für den {} Anspruch in der Tabelle auswählt',
  async function (this: ICustomWorld, param: string) {
    await this.nachzahlungUndAnsprüche?.editAnspruch(param);
  },
);

When(
  'die Sachbearbeitung das Hinzufügen einer neuen Forderung auswählt',
  async function (this: ICustomWorld) {
    await this.nachzahlungUndAnsprüche?.addErstattungsanspruch();
  },
);
When(
  'die Sachbearbeitung den Eintrag Nr. {} in der Tabelle löscht',
  async function (this: ICustomWorld, param: string) {
    await this.nachzahlungUndAnsprüche?.deleteErstattungsstelle(param);
  },
);
When('die Sachbearbeitung das Löschen bestätigt', async function (this: ICustomWorld) {
  await this.nachzahlungUndAnsprüche?.deleteConfirm();
});

Then(
  'erscheint ein neuer Eintrag an der {}. Stelle mit den zuvor eingegebenen Daten',
  async function (this: ICustomWorld, stelle: string) {
    const nummer: number = +stelle;
    expect(await this.nachzahlungUndAnsprüche?.getErstattungsstelleName(nummer)).toEqual(
      await this.erstattungsanspruchForm?.getValidErstattungsstelle(),
    );
  },
);

Then(
  'öffnet sich die Nachzahlung und Ansprüche Seite mit der Erstattungsansprüche Tabelle',
  async function (this: ICustomWorld) {
    expect(await this.nachzahlungUndAnsprüche?.getNachzahlungTitle()).toEqual(
      'Nachzahlung und Ansprüche',
    );
  },
);

Then('die Sachbearbeitung aktualisiert die Seite', async function (this: ICustomWorld) {
  await this.page?.reload();
  await this.page?.waitForLoadState('networkidle');
});

Then(
  'erwarte ich, dass {} für den {}. Anspruch in der Tabelle sichtbar ist',
  async function (this: ICustomWorld, herkunft: string, nr: string) {
    const nummer: number = +nr;
    if (herkunft == 'das Maschinell-Icon') {
      await expect(
        await this.nachzahlungUndAnsprüche!.getForderungAnspruchMaschinellIconTabelle(nummer),
      ).toBeVisible();
    } else if (herkunft == 'das Manuell-Icon') {
      await expect(
        await this.nachzahlungUndAnsprüche!.getForderungAnspruchManuellIconTabelle(nummer),
      ).toBeVisible();
    } else {
      await expect(
        await this.nachzahlungUndAnsprüche!.getForderungAnspruchManuellIconTabelle(nummer),
      ).toBeVisible();
      await expect(
        await this.nachzahlungUndAnsprüche!.getForderungAnspruchMaschinellIconTabelle(nummer),
      ).toBeVisible();
    }
  },
);

When(
  'der Restbetrag auf der Seite Nachzahlung und Ansprüche größer {int} ist',
  async function (this: ICustomWorld, expectedRestbetrag: number) {
    const page = this.page!;
    while ((await page.locator('#nachzahlungRestbetragLabel').innerText()) == '') {
      await setTimeout(50);
    }
    const restbetrag = await page.locator('#nachzahlungRestbetrag').textContent();
    if (!restbetrag) {
      throw new Error('Auf der Seite ist kein Restbetrag vorhanden');
    }
    const restbetragFloat = parseFloat(
      restbetrag.replace('€', '').trim().replaceAll('.', '').replace(',', '.'),
    );
    expect(restbetragFloat).toBeGreaterThan(expectedRestbetrag);
  },
);

Then(
  'erwarte ich als Zeitraum der Nachzahlung {}, als Leistungsart {}, als Bescheiddatum {} und als Höhe der Rentennachzahlung {} Euro',
  async function (
    this: ICustomWorld,
    nachzahlungsZeitraum: string,
    leistungsart: string,
    bescheidDatum: string,
    nachzahlungsBetrag: string,
  ) {
    expect(await this.nachzahlungUndAnsprüche?.getNachzahlungsZeitraum()).toEqual(
      nachzahlungsZeitraum,
    );
    expect(await this.nachzahlungUndAnsprüche?.getLeistungsart()).toEqual(leistungsart);
    expect(await this.nachzahlungUndAnsprüche?.getBescheidDatum()).toEqual(bescheidDatum);
    expect(await this.nachzahlungUndAnsprüche?.getNachzahlungsBetrag()).toEqual(nachzahlungsBetrag);
  },
);

Then(
  'erwarte ich an der {}. Stelle einen Erstattungsanspruch von {}',
  async function (this: ICustomWorld, stelle: string, erstattungsstelle: string) {
    const nummer: number = +stelle;
    expect(await this.nachzahlungUndAnsprüche?.getErstattungsstelleName(nummer)).toEqual(
      erstattungsstelle,
    );
  },
);

Then(
  'erwarte ich eine Summe der Erstattungsansprüche in Höhe von {} Euro',
  async function (this: ICustomWorld, summeAnsprüche: string) {
    expect(await this.nachzahlungUndAnsprüche?.getSummeAnsprüche()).toEqual(summeAnsprüche);
  },
);

Then(
  'erwarte ich einen Restbetrag in Höhe von {} Euro',
  async function (this: ICustomWorld, summeRestbetrag: string) {
    expect(await this.nachzahlungUndAnsprüche?.getSummeRestbetrag()).toEqual(summeRestbetrag);
  },
);

Then(
  'die Sachbearbeitung löscht den Eintrag {} in der Tabelle',
  async function (this: ICustomWorld, param: string) {
    await this.nachzahlungUndAnsprüche?.deleteErstattungsstelle(param);
    await this.page?.waitForTimeout(config.timeout.short);
    await this.nachzahlungUndAnsprüche?.deleteConfirm();
    await this.page?.waitForTimeout(config.timeout.medium);
  },
);
Then(
  'erwarte ich für den {}. Zeitraum mit dem Adressschlüssel "{}" einen Erstattungsanspruch in Höhe von {} Euro',
  async function (
    this: ICustomWorld,
    eintragNummer: number,
    adressschluessel: string,
    erwarteterBetrag: string,
  ) {
    const actualBetrag = await this.nachzahlungUndAnsprüche?.getErstattungsanspruchsbetrag(
      eintragNummer - 1,
      adressschluessel,
    );

    expect(actualBetrag).toEqual(erwarteterBetrag);
  },
);
Then(
  'wird die Sachbearbeitung die folgende Fehlermeldung "Rangfolge fehlerhaft. Bitte korrigieren." für den {} Anspruch in der Tabelle erscheinen',
  async function (this: ICustomWorld, param: string) {
    const text = await this.nachzahlungUndAnsprüche?.getRangfolgeFehlerhaft(param);
    expect(text).toEqual('Rangfolge fehlerhaft. Bitte korrigieren.');
  },
);
Then(
  'wird die Sachbearbeitung den folgenden Hinweis "kein Anspruch geltend gemacht" für den {} Anspruch in der Tabelle erscheinen',
  async function (this: ICustomWorld, param: string) {
    const text = await this.nachzahlungUndAnsprüche?.getHinweisKeinAnspruchGeltendGemacht(param);
    expect(text).toEqual('Kein Anspruch geltend gemacht');
  },
);
Then(
  'wird die Sachbearbeitung den folgenden Hinweis "Antwort ausstehend" für den {} Anspruch in der Tabelle erscheinen',
  async function (this: ICustomWorld, param: string) {
    const text = await this.nachzahlungUndAnsprüche?.getTextErstattungHinweis(param);
    expect(text).toEqual('Antwort ausstehend');
  },
);
Then(
  'soll der Versicherten Name "{}" und Vorname "{}" mit der Rentenberechtigten Person Name "{}" und Vorname "{}" übereinstimmen',
  async function (
    this: ICustomWorld,
    expectedName: string,
    expectedVorname: string,
    expectedRentenBerechtigePersonName: string,
    expectedRentenBerechtigePersonVorname: string,
  ) {
    const name = await this.nachzahlungUndAnsprüche?.getVersicherterName();
    const nameSplit = name?.trim().split(', ');
    const actualName = nameSplit![0];
    const actualVorname = nameSplit![1];
    const actualRentenBerechtigtePersonName =
      await this.nachzahlungUndAnsprüche?.getRentenBerechtigePersonName();
    const actualRentenBerechtigtePersonVorname =
      await this.nachzahlungUndAnsprüche?.getRentenBerechtigePersonVorname();

    if (actualName === '') {
      throw new Error('Der VersichertenName ist leer oder nicht vorhanden.');
    }
    if (actualVorname === '') {
      throw new Error('Der VersichertenVorname ist leer oder nicht vorhanden.');
    }

    expect(actualName).toContain(expectedName);
    expect(actualVorname).toContain(expectedVorname);
    expect(actualRentenBerechtigtePersonName).toContain(expectedRentenBerechtigePersonName);
    expect(actualRentenBerechtigtePersonVorname).toContain(expectedRentenBerechtigePersonVorname);
  },
);
Then(
  'wird die Sachbearbeitung den Hinweis "{}" angezeigt bekommen',
  async function (this: ICustomWorld, hinweistext: string) {
    expect(await this.nachzahlungUndAnsprüche?.getMeldungKeinRestBetrag()).toEqual(hinweistext);
  },
);

// Then(
//   'soll der VersichertenName {string} und Vorname {string} nicht mit dem Rentenberechtigte Person übereinstimmen',
//   async function (this: ICustomWorld, expectedName: string, expectedVorname: string) {
//     const actualName = await this.nachzahlungUndAnsprüche?.getVersicherterName();
//     const actualVorname = await this.nachzahlungUndAnsprüche?.getVersicherterVorname();

//     expect(actualName).toContain(expectedName);
//     expect(actualVorname).toContain(expectedVorname);
//   },
// );
