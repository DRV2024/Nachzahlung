import { ICustomWorld } from '../support/custom-world';
import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

When('die Sachbearbeitung Bearbeitung abschließen auswählt', async function (this: ICustomWorld) {
  await this.navigation?.schliesseBearbeitung();
  await this.page?.waitForLoadState('networkidle');
});
When(
  'die Sachbearbeitung zur Verzinsung die Schaltfläche Bearbeitung abschließen auswählt',
  async function (this: ICustomWorld) {
    await this.navigation?.schliesseVerzinsung();
  },
);
When(
  'die Sachbearbeitung Bearbeitung abschließen auf der Zinsen Seite auswählt',
  async function (this: ICustomWorld) {
    await this.navigation?.schliesseVerzinsung();
  },
);

When('die Sachbearbeitung zurück zur Übersicht navigiert', async function (this: ICustomWorld) {
  await this.navigation?.navigateToUebersicht();
});

When('die Sachbearbeitung weiter zur Verzinsung navigiert', async function (this: ICustomWorld) {
  await this.navigation?.navigateToVerzinsung();
});

When(
  'die Sachbearbeitung Abrechnung anzeigen auf der Erfolgsseite auswählt',
  async function (this: ICustomWorld) {
    await this.navigation?.showAbrechnung();
  },
);

Then('zeigt die Schaltfläche Weiter zur Verzinsung', async function (this: ICustomWorld) {
  expect(await this.navigation?.getVerzinsungsBtn()).toEqual('Weiter zur Verzinsung');
});

Then(
  'ist die Schaltfläche Weiter zur Verzinsung {}',
  async function (this: ICustomWorld, insensitiv: string) {
    const page = this.page!;
    if (insensitiv === 'insensitiv') {
      await expect(page.locator('#verzinsungBtn')).toBeDisabled;
    } else if (insensitiv === 'sensitiv') {
      await expect(page.locator('#verzinsungBtn')).toBeEnabled;
    }
  },
);

Then('zeigt die Schaltfläche Bearbeitung abschließen', async function (this: ICustomWorld) {
  expect(await this.navigation?.getAbrechneBtn()).toEqual('Bearbeitung abschließen');
});

Then(
  'ist die Schaltfläche Bearbeitung abschließen {}',
  async function (this: ICustomWorld, insensitiv: string) {
    const page = this.page!;
    if (insensitiv === 'insensitiv') {
      await expect(page.locator('#abrechnenBtn')).toBeDisabled;
    } else if (insensitiv === 'sensitiv') {
      await expect(page.locator('#abrechnenBtn')).toBeEnabled;
    }
  },
);

Then('kann die Sachbearbeitung die Bearbeitung abschließen', async function (this: ICustomWorld) {
  const page = this.page!;
  await expect(page.locator('#abschlussBtn')).toBeEnabled();
});

Then(
  'die Sachbearbeitung kann die Bearbeitung nicht abschließen',
  async function (this: ICustomWorld) {
    const page = this.page!;
    await expect(page.locator('#abschlussBtn')).toBeDisabled;
  },
);

Then('öffnet sich die Seite Nachzahlung und Ansprüche', async function (this: ICustomWorld) {
  expect(await this.verzinsungsUebersicht?.getVerzinsungsTitle()).toEqual(
    'Nachzahlung und Ansprüche',
  );
});

Then('öffnet sich die Seite Nachzahlung und Zinsen', async function (this: ICustomWorld) {
  expect(await this.verzinsungsUebersicht?.getVerzinsungsTitle()).toEqual('Nachzahlung und Zinsen');
});

When(
  'öffnet sich die Seite Übersicht zur Nachzahlung mit den Erstattungsansprüchen und den errechneten Zinsen',
  async function (this: ICustomWorld) {
    expect(await this.verzinsungsUebersicht?.getVerzinsungsTitle()).toEqual(
      'Übersicht zur Nachzahlung',
    );
  },
);

When('zeigt die Schaltfläche Abrechnung anzeigen', async function (this: ICustomWorld) {
  expect(await this.navigation?.getAbrechneBtn()).toEqual('Abrechnung anzeigen');
});

When(
  'ist die Schaltfläche Abrechnung anzeigen {}',
  async function (this: ICustomWorld, insensitiv: string) {
    const page = this.page!;
    if (insensitiv === 'insensitiv') {
      await expect(page.locator('#AbrechnungAnzeigenBtn')).toBeDisabled;
    } else if (insensitiv === 'sensitiv') {
      await expect(page.locator('#AbrechnungAnzeigenBtn')).toBeEnabled;
    }
  },
);

Then(
  'wird der Sachbearbeitung die Schaltfläche Zurück zur Übersicht angezeigt',
  async function (this: ICustomWorld) {
    expect(await this.navigation?.getZurueckBtn()).toEqual('Zurück zur Übersicht');
  },
);

Then('wird der Sachbearbeitung die Abschluß-Seite angezeigt', async function (this: ICustomWorld) {
  const page = this.page!;
  await expect(page.locator('app-nachzahlung-verzinsung-abschluss')).toBeVisible();
});
