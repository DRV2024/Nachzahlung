import { ICustomWorld } from '../support/custom-world';
import { Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Then(
  'folgenden Angaben zur Versicherten Person: {}, {}, {}',
  async function (this: ICustomWorld, versicherungsnummer: string, name: string, vorname: string) {
    await expect([
      await this.versichertenHeader?.getVersicherterVSNR(),
      await this.versichertenHeader?.getVersicherterName(),
      await this.versichertenHeader?.getVersicherterVorname(),
    ]).toEqual([versicherungsnummer, name, vorname]);
  },
);
