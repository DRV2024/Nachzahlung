/* eslint-disable indent */
/* eslint-disable prettier/prettier */
import { ICustomWorld } from '../../support/custom-world';
import { getApiBaseUrl } from '../../support/environments';
import { getBestandsToken } from '../general.steps';
import { getKeycloakToken } from '../../support/config';
import { expect } from '@playwright/test';
import { Given, Then, When } from '@cucumber/cucumber';

Given('ich keinen request body für die Nachzahlungen habe', function (this: ICustomWorld) {
  this.requestBody = null;
});
When(
  'ich einen PATCH Request mit eingangsdatumRentenantrag an die URL für Nachzahlungen mit der VorgangsId = {} und KTAN 17 absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', // drv-mandat Header hinzugefügt
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 
      },
      json: true,
      data: {
        eingangsdatumRentenantrag: '2021-03-14',
      },
    };
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options,
    );
  },
);
When(
  'ich einen PATCH Request mit eingangsdatumRentenantrag für das Jahr 2022 an die URL für Nachzahlungen mit der VorgangsId = {} und KTAN 17 absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', // drv-mandat Header hinzugefügt
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 
      },
      json: true,
      data: {
        eingangsdatumRentenantrag: '2022-03-01',
      },
    };
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options,
    );
  },
);
When(
  'ich einen PATCH Request mit eingangsdatumRentenantrag für das Jahr 2021 an die URL für Nachzahlungen mit der VorgangsId = {} und KTAN 17 absende',
  async function (this: ICustomWorld, vorgangsId: string) {
        this.accessToken = await getKeycloakToken('PR_NzV_BST');
    this.requestPath = 'nachzahlungen';
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', // drv-mandat Header hinzugefügt
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 
      },
      json: true,
      data: {
        eingangsdatumRentenantrag: '2021-03-14',
      },
    };
    console.log(this.accessToken);
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options,
    );
  },
);
When(
  'ich einen PATCH Request mit unsupported Media Type und eingangsdatumRentenantrag an die URL für Nachzahlungen mit der VorgangsId = {} und KTAN 17 absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'text/plain', // Falscher Content-Type
        'drv-mandant': '17', // drv-mandat Header hinzugefügt
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 

      },

      // json: true entfernen, da dies den Content-Type auf application/json setzen würde
      data: 'eingangsdatumRentenantrag=2022-03-16', // Kein JSON, nur Text
    };

    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options,
    );

    console.log('HTTP Response: ', this.requestResponse);
  },
);
When(
  'ich einen PATCH Request mit falschem Format an die URL für Nachzahlungen mit der VorgangsId = {} und KTAN 17 absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', // drv-mandat Header hinzugefügt
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 

      },
      json: true,
      data: {
        antrag: '2022-03-16',
      },
    };
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options,
    );
    console.log('HTTP Response: ', this.requestResponse);
  },
);

When(
  'ich einen PATCH Request ohne request body an die URL für Nachzahlungen mit der VorgangsId = {} absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      {
        data: {},
      },
    );
  },
);

When(
  'ich einen PATCH Request mit unvollständigem request body an die URL für Nachzahlungen mit der VorgangsId = {} absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      {
        data: { eingangsdatumRentenantrag: '2022-03' },
      },
    );
  },
);
When(
  'ich einen PATCH Request mit zu vielen Attributen an die URL für Nachzahlungen mit der VorgangsId = {} absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      {
        data: {
          eingangsdatumRentenantrag: '2022-03-12',
          zusätzlichesAttribut: 'zusätzlicher Wert',
        },
      },
    );
  },
);
When(
  'ich falsche Attribute im request body für die Nachzahlungen habe',
  function (this: ICustomWorld) {
    this.requestBody = {
      ungültigesAttribut: 'ein falscher Wert', // Falsches Attribut
      zeitraum: {
        von: '2023-06-12',
        bis: '2023-06-12',
      },
      erstattungsAnsprueche: [
        {
          erstattungsStelle: 'string',
          gesamtAnspruch: 0,
          forderung: '/erstattungs-forderungen/12345/X51',
          teilAnsprueche: [
            {
              summeForderung: 0,
              summeAnsprueche: 0,
              zeitraum: {
                von: '2023-06-12',
                bis: '2023-06-12', //hier für PATCH ändern
              },
            },
          ],
        },
      ],
      vorgangsId: 'string',
      leistungsArt: 'string',
      bescheidDatum: '2023-06-12',
      bescheidNummer: 'st',
      eingangRentenantrag: '2023-06-12',
      ktan: 'st',
      gesamtBetrag: 0,
      gesamtRestBetrag: 0,
      gesamtAnspruch: 0,
      status: 'IN_BEARBEITUNG',
      hinweise: [
        {
          hinweistyp: 'INFO',
          hinweisart: 'ERSTATTUNGSTEILBETRAG_BEGRENZUNG',
          referenzId: 0,
        },
      ],
      verzinsung: {
        zeitraum: {
          von: '2023-06-12',
          bis: '2023-06-12',
        },
        zinsSumme: 0,
        verzinsungZeitraeume: [
          {
            einzelZeitraum: {
              von: '2023-06-12',
              bis: '2023-06-12',
            },
            zuVerzinsenderBetrag: 0,
            zinsen: 0,
            nachzahlungMonatJahr: {
              year: 0,
              month: 0,
              prolepticMonth: 0,
              monthValue: 0,
              leapYear: true,
            },
            zinsMonatJahr: {
              year: 0,
              month: 0,
              prolepticMonth: 0,
              monthValue: 0,
              leapYear: true,
            },
          },
        ],
      },
    };
  },
);
When(
  'ich falsche Daten in den Attributen des request body für die Nachzahlungen habe',
  function (this: ICustomWorld) {
    this.requestBody = {
      zeitraum: {
        von: '2023-06-12',
        bis: '2023-06-12',
      },
      erstattungsAnsprueche: [
        {
          erstattungsStelle: 'string',
          gesamtAnspruch: -100, // Negative Werte sind nicht erlaubt
          forderung: '/erstattungs-forderungen/12345/X51',
          teilAnsprueche: [
            {
              summeForderung: 0,
              summeAnsprueche: 0,
              zeitraum: {
                von: '2023-06-12',
                bis: '2023-06-12', //hier für PATCH ändern
              },
            },
          ],
        },
      ],
      vorgangsId: 'string',
      leistungsArt: 'string',
      bescheidDatum: '2023-06-12',
      bescheidNummer: 'st',
      eingangRentenantrag: '2023-06-12',
      ktan: 'st',
      gesamtBetrag: 0,
      gesamtRestBetrag: 0,
      gesamtAnspruch: 0,
      status: 'IN_BEARBEITUNG',
      hinweise: [
        {
          hinweistyp: 'INFO',
          hinweisart: 'ERSTATTUNGSTEILBETRAG_BEGRENZUNG',
          referenzId: 0,
        },
      ],
      verzinsung: {
        zeitraum: {
          von: '2023-06-12',
          bis: '2023-06-12',
        },
        zinsSumme: 0,
        verzinsungZeitraeume: [
          {
            einzelZeitraum: {
              von: '2023-06-12',
              bis: '2023-06-12',
            },
            zuVerzinsenderBetrag: 0,
            zinsen: 0,
            nachzahlungMonatJahr: {
              year: 0,
              month: 0,
              prolepticMonth: 0,
              monthValue: 0,
              leapYear: true,
            },
            zinsMonatJahr: {
              year: 0,
              month: 0,
              prolepticMonth: 0,
              monthValue: 0,
              leapYear: true,
            },
          },
        ],
      },
    };
  },
);
Then(
  'sollte ich eine 200 Antwort mit diesem eingangsdatumRentenantrag erhalten',
  async function (this: ICustomWorld) {
    const responseStatus = this.requestResponse?.status();
    expect(responseStatus).toBe(200);
  },
);
Then(
  'sollte ich eine 200 Antwort mit diesem eingangsdatumRentenantrag 2022 erhalten',
  async function (this: ICustomWorld) {
    const responseStatus = this.requestResponse?.status();
    expect(responseStatus).toBe(200);
    }
);
