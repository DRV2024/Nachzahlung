/* eslint-disable indent */
/* eslint-disable prettier/prettier */
import { ICustomWorld } from '../../support/custom-world';
import { getApiBaseUrl } from '../../support/environments';
import { getBestandsToken } from '../general.steps';
import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Given('ich rufe den Uebertragungen Endpunkt auf', function (this: ICustomWorld) {
  this.requestPath = 'uebertragungen';
});
Given('ich keinen request body für für die Uebertragungen habe', function (this: ICustomWorld) {
  this.requestBody = null;
});
When(
  'ich einen POST Request an die Uebertragungen einer Nachzahlung mit der VorgangsId = {} und KTAN 17 absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', // drv-mandat Header hinzugefügt
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 

      },
      json: true,
    };

    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options, // options enthalten nun die Body Daten
    );
  },
);

Then(
  'sollte ich eine 201 Antwort für die Uebertragung erhalten',
  async function (this: ICustomWorld) {
    const responseStatus = this.requestResponse?.status();
    expect(responseStatus).toBe(201);
  },
);
Then('sollte ich für die Übertragung eine 400 Antwort erhalten', function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(400);
});
