/* eslint-disable prettier/prettier */
import { ICustomWorld } from '../../support/custom-world';
import { getApiBaseUrl } from '../../support/environments';
import { getBestandsToken } from '../general.steps';
import { Then, When, Given } from '@cucumber/cucumber';

import { expect } from '@playwright/test';

Given(
  'ich habe einen gültigen aktualisierten request body für ErstattungsForderung',
  function (this: ICustomWorld) {
    this.requestBody = {
      vorgangsId: 0,
      erstattungsStelle: {
        name: 'string',
        adressschluessel: 'string',
      },
      forderungsZeitraeume: [
        {
          zeitraum: {
            von: '2023-09-21',
            bis: '2023-09-21', //hier für PATCH ändern
          },
          betrag: 999999.99,
          auszahlungsJahr: 0,
        },
      ],
      bearbeitungsstatus: 'loeschbar',
      geaendert: 'JA',
      rechtsgrundlage: 'SGB103X',
      aktenzeichen: 'string',
      verfahrensstand: 'PAPIER',
      buchungszeichen: 'string',
      dokumentNrRvpur: 'string',
    };
  },
);

When(
  'ich einen PATCH ohne request body an die URL mit der VorgangsId = {} und AdressSchluessel {} absende',
  async function (this: ICustomWorld, vorgangsId: string, adressSchluessel: string) {
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}/${adressSchluessel}`,
      {
        data: {},
      },
    );
  },
);

When(
  'ich einen PATCH mit unvollständigem reqeust body an die URL mit der VorgangsId = {} und AdressSchluessel {} absende',
  async function (this: ICustomWorld, vorgangsId: string, adressSchluessel: string) {
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}/${adressSchluessel}`,
      {
        data: {
          forderungsZeitraeume: [
            {
              betragForderung: 111,
              zeitraum: {
                von: '2022-01-31',
                bis: '2022-01-31',
              },
            },
          ],
          erstattungsstelle: {
            name: 'Knappschaft',
            adressschluessel: 'R93',
          },
          aktenzeichen: 'AVBFGT',
          buchungszeichen: '123456',
          dokumentNrRvpur: '35',
        },
      },
    );
  },
);
When(
  'ich einen PATCH Request mit zu vielen Attributen im request body an die URL mit der VorgangsId = {} und AdressSchluessel {} absende',
  async function (this: ICustomWorld, vorgangsId: string, adressSchluessel: string) {
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}/${adressSchluessel}`,
      {
        data: {
          forderungsZeitraeume: [
            {
              betragForderung: 111,
              zeitraum: {
                von: '2022-01-31',
                bis: '2022-01-31',
                zusätzlichesAttribut: 'zusätzlicher Wert',
              },
            },
          ],
          erstattungsstelle: {
            name: 'Knappschaft',
            adressschluessel: 'R95',
            zusätzlichesAttribut: 'zusätzlicher Wert',
          },
          rechtsgrundlage: 'SGB103X',
          aktenzeichen: 'AVBFGT',
          buchungszeichen: '123456',
          dokumentNrRvpur: '35',
          zusätzlichesAttribut: 'zusätzlicher Wert',
        },
      },
    );
  },
);
When(
  'ich einen PATCH Request mit falschen Daten in den Attributen an die URL mit der VorgangsId = {} und AdressSchluessel {} absende',
  async function (this: ICustomWorld, vorgangsId: string, adressSchluessel: string) {
    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}/${adressSchluessel}`,
      {
        data: {
          forderungsZeitraeume: [
            {
              betragForderung: 'falscher Wert',
              zeitraum: {
                von: '20220131',
                bis: '20220131',
              },
            },
          ],
          erstattungsstelle: {
            name: false,
            adressschluessel: 'R93',
          },
          rechtsgrundlage: 'SGB103X',
          aktenzeichen: 'AVBFGT',
          buchungszeichen: '123456',
          dokumentNrRvpur: '35',
        },
      },
    );
  },
);
When(
  'ich einen PATCH Request an die Erstattungsforderung URL mit der VorgangsId = {} und AdressSchluessel {} und KTAN 17 absende',
  async function (this: ICustomWorld, vorgangsId: string, adressschluessel: string) {
    const body = {
      forderungsZeitraeume: [
        {
          betragForderung: 150,
          zeitraum: {
            von: '2022-08-01',
            bis: '2022-08-15',
          },
        },
      ],
      rechtsgrundlage: 'SGB103X',
      aktenzeichen: '89431083',
      buchungszeichen: '123456',
      dokumentNrRvpur: '00096',
    };
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', // drv-mandat Header hinzugefügt
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 

      },
    };

    this.requestResponse = await this.requestContext?.patch(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}/${adressschluessel}`,
      {
        ...options,
        data: body,
      },
    );
  },
);

Then(
  'sollte ich eine 204 Antwort erhalten und die Erstattungsforderung ist erfolgreich aktualisiert',
  async function (this: ICustomWorld) {
    expect(this.requestResponse?.status()).toBe(204);
  },
);
