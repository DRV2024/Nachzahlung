/* eslint-disable indent */
/* eslint-disable prettier/prettier */
import { ICustomWorld } from '../../support/custom-world';
import { getApiBaseUrl } from '../../support/environments';
import { getBestandsToken } from '../general.steps';
import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

When(
  'ich einen DELETE Request an die URL mit der VorgangsId = {} und AdressSchluessel = {} und KTAN 17 absende',
  async function (this: ICustomWorld, vorgangsId: string, adressSchluessel: string) {
    const url = `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}/${adressSchluessel}`;
    const requestOptions = {
      url: url,
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', // drv-mandat Header hinzugefügt
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 

      },
      json: true,
    };

    try {
      this.requestResponse = await this.requestContext?.delete(url, requestOptions);
    } catch (error) {
      console.error('Fehler bei der API-DELETE-Anfrage:', error);
      throw error;
    }
  },
);
Then('sollte ich eine 204 Antwort erhalten', async function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(204);
});
Then(
  'sollte ich eine 204 bekommen und die Erstattungsforderung wurde erfolgreich gelöscht',
  async function (this: ICustomWorld) {
    expect(this.requestResponse?.status()).toBe(204);
  },
);
