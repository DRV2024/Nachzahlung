/* eslint-disable import/order */
/* eslint-disable prettier/prettier */
/* eslint-disable indent */
import { ICustomWorld } from '../../support/custom-world';
import { When, Given, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { expectedBodyNachzahlungen } from '../../data/responseBody_NachzahlungenGET';
import { getApiBaseUrl } from '../../support/environments';
import { getBestandsToken } from '../general.steps';
import { getKeycloakToken } from '../../support/config';

Given('ich rufe die Nachzahlung API mit vsnr auf', function (this: ICustomWorld) {
  this.requestPath = 'nachzahlungen?vsnr=';
});
Given('ich rufe die Nachzahlung API auf', function (this: ICustomWorld) {
  this.requestPath = 'nachzahlungen';
});
When(
  'ich einen GET Request an die URL für Nachzahlungen mit der VSNR {} und KTAN 17 absende',
  async function (this: ICustomWorld, VSNR: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', 
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 
      },
      json: true,
    };

    try {
      this.requestResponse = await this.requestContext?.get(
        `${getApiBaseUrl()}/${this.requestPath}${VSNR}`,
        options,
      );
    } catch (error) {
      console.error('Fehler bei der API-GET-Anfrage:', error);
      throw error;
    }
          console.log(this.requestResponse);

  },
);
When(
  'ich einen GET Request an die URL für Nachzahlungen mit der VorgangsId = {} und KTAN 17 absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', 
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 
      },
      json: true,
    };

    try {
      this.requestResponse = await this.requestContext?.get(
        `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
        options,
      );
    } catch (error) {
      console.error('Fehler bei der API-GET-Anfrage:', error);
      throw error;
    }
  },
);
When(
  'die Nachzahlung wird mit GET abgerufen für die Vorgangsid = {}',
  async function (this: ICustomWorld, nachzahlung_id: string): Promise<void> {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
      },
      json: true,
    };

    try {
      this.requestResponse = await this.requestContext?.get(
        `${getApiBaseUrl()}/nachzahlungen/${nachzahlung_id}`,
        options,
      );
    } catch (error) {
      console.error('Fehler bei der API-GET-Anfrage:', error);
      throw error;
    }
  },
);

Then(
  'sollte ich eine 200 für die Nachzahlungen Antwort erhalten',
  async function (this: ICustomWorld) {
    const responseStatus = this.requestResponse?.status();
    expect(responseStatus).toBe(200);
    if (responseStatus === 200) {
      const buffer = await this.requestResponse?.body();
      const result = JSON.parse(buffer!.toString());
      expect(result).toEqual(expectedBodyNachzahlungen);
    }
  },
);

Then(
  'sollte ich eine 200er Antwort mit korrektem Restbetrag = {} erhalten',
  async function (this: ICustomWorld, RestbetragValue: string) {
    const Restbetrag = parseFloat(RestbetragValue);

    // Status überprüfen
    expect(this.requestResponse?.status()).toBe(200);

    if (this.requestResponse?.body) {
      // Buffer in String konvertieren und dann in JSON parsen
      const body = JSON.parse((await this.requestResponse.body()).toString());

      // Restbetrag überprüfen
      expect(body.gesamtRestbetrag).toBe(Restbetrag);
    } else {
      throw new Error('Body ist undefined');
    }
  },
);
Then(
  'sollte ich eine 200 Antwort für Nachzahlungen zu der angegebenen VorgangsId erhalten',
  async function (this: ICustomWorld) {
    const responseStatus = this.requestResponse?.status();
    expect(responseStatus).toBe(200);
  },
);
Then(
  'sollte der Status in der JSON-Antwort "{}" sein für die VorgangsID = {}',
  async function (this: ICustomWorld, status: string, vorgangsId: string) {
    this.accessToken = await getKeycloakToken('PR_NzV_BST');
    this.requestPath = 'nachzahlungen';
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Bestand-Authorization': `Bearer ${getBestandsToken()}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', // drv-mandat Header hinzugefügt
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 
      },
      json: true,
    };
      console.log('AccessToken:', this.accessToken);
      console.log('BestandsToken:', getBestandsToken());
    try {
      this.requestResponse = await this.requestContext?.get(
        `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
        options,
      );
      console.log('API-Antwort-Status:', this.requestResponse?.status());
      console.log('API-Antwort-Inhalt:', await this.requestResponse?.text());

      if (this.requestResponse?.ok) {
        const responseBody = await this.requestResponse.json();
        expect(responseBody.status).toBe(status);
      } else {
        throw new Error(`API-Anfrage fehlgeschlagen mit Statuscode ${this.requestResponse?.status()}`);
      }
    } catch (error) {
      console.error('Fehler bei der API-GET-Anfrage:', error);
      throw error;
    }
  },
);