/* eslint-disable prettier/prettier */
/* eslint-disable indent */
import { ICustomWorld } from '../../support/custom-world';
import { getKeycloakToken } from '../../support/config';
import { Given, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
// import exp from 'constants';
Given('ich rufe die Erstattungsforderung API auf', function (this: ICustomWorld) {
  this.requestPath = '/erstattungen/forderungen';
});

Given(
  'die Sachbearbeitung hat die Berechtigung um auf die Ressource zuzugreifen',
  async function (this: ICustomWorld) {
    this.accessToken = await getKeycloakToken('PR_NzV_BST');
    console.log(this.accessToken);
  },
);
Given(
  'die Sachbearbeitung hat keine Berechtigung um auf die Ressource zuzugreifen',
  async function (this: ICustomWorld) {
    this.accessToken = await getKeycloakToken('sb_no_role');
        console.log(this.accessToken);
  },
);
Given('das Gateway hat die Rolle TR_NzV_GW', async function (this: ICustomWorld) {
  this.accessToken = await getKeycloakToken('TR_NzV_GW');
});
Given('ich habe einen falschen Authentifizierungs-Token', async function (this: ICustomWorld) {
  this.accessToken = 'invalid-token';
});
Given('ich habe einen abgelaufenen Authentifizierungs-Token', async function (this: ICustomWorld) {
  this.accessToken =
    'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJWSHBDaDJsMlFvdWpXelYtLWpuN2c0dWFfdzBuV19wazVCNC1ibHphZ3E0In0.eyJleHAiOjE2ODg0NjQ1MDIsImlhdCI6MTY4ODQ2NDIwMiwiYXV0aF90aW1lIjoxNjg4NDUzMDM4LCJqdGkiOiJmYjIzNTU5Ny0zNGRkLTRmZjQtODkzNi04ZmYwNDM1OWIxNjAiLCJpc3MiOiJodHRwczovL2tleWNsb2FrLXJ2ZXZvLWRlbW8uYXBwcy5vcy1ldm8uZW50dy5idW5kLmRydi9yZWFsbXMvcnZFdm9aZW50cmFsIiwic3ViIjoiMTU4YjdhMDUtZDA5MS00ZGFkLTk1YmEtNTVkNDkzNzE0MTI4IiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiZnJvbnRlbmQiLCJub25jZSI6ImRWTXpNMjl6WjBrdGNqbGtiM05NVjNRdVZDNWFiVlZYVW10T2RsZHFjVU5zWWxSWFMwOW5SRmt3YW05ayIsInNlc3Npb25fc3RhdGUiOiI4ODQ5YjA1Yi01MzU0LTQwYTYtYTY2NC1lNzE4YTNiNDJiNjkiLCJzY29wZSI6Im9wZW5pZCBkcnYgbWljcm9wcm9maWxlLWp3dCIsInNpZCI6Ijg4NDliMDViLTUzNTQtNDBhNi1hNjY0LWU3MThhM2I0MmI2OSIsInVwbiI6InRlc3QiLCJkcnZJZCI6IjAwMDAwMDAwMDAwMDEiLCJncm91cHMiOlsiU0JfTlZfRlVMTCIsIm9mZmxpbmVfYWNjZXNzIiwiYWRtaW4iLCJTQl9GSVRfRlVMTCIsInVtYV9hdXRob3JpemF0aW9uIiwiZGVmYXVsdC1yb2xlcy1ydmV2b3plbnRyYWwiXSwicHJlZmVycmVkX3VzZXJuYW1lIjoidGVzdCIsImdpdmVuX25hbWUiOiIiLCJmYW1pbHlfbmFtZSI6IiJ9.JNOk3qPp7i_v21bePhShs44hKzKYIYIJUoMchLnxF-RiNhsxaKAAKKnTI9NE1EbhIzjsSITwIAtL3p3Avksv7OJaruUHtYIbxu8cPYIVtIUdSnIjvuA-Y1_0MEv-TqgflkdT1Ld9KJmC4j1XzGNal7vWx6OlLjvMt0L90ngqzVIm2BgwZS-vJzJDxcZOorQM7_PIAsANqvlZFNHe6rCSPHnnzO9DU5k99N29XD_zh4I_ElcCXYkoJPNRfExpZCY1mKGczoPxLe2noDWGfW_aBsAvtJjBBaMAUUZTpghwwgLV2Z9zZa5MqnmeRnG-bFeo3QuMXEDPUpfF2B01DqFOZQ';
});

Then('sollte ich eine 200 Antwort erhalten', async function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(200);
});
Then('sollte ich eine 201 Antwort erhalten', async function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(201);
});
Then('sollte ich eine 404 Antwort erhalten', function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(404);
});
Then('sollte ich eine 403 Antwort erhalten', function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(403);
});
Then('sollte ich eine 405 Antwort erhalten', function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(405);
});
Then(
  'sollte ich eine 403 Antwort erhalten und die Nachzahlung sollte mir nicht angezeigt werden',
  function (this: ICustomWorld) {
    expect(this.requestResponse?.status()).toBe(403);
  },
);
