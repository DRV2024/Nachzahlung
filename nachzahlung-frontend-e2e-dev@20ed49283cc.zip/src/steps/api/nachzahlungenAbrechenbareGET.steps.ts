/* eslint-disable import/order */
/* eslint-disable prettier/prettier */
/* eslint-disable indent */
import { ICustomWorld } from '../../support/custom-world';
import { When, Given, Then } from '@cucumber/cucumber';
import { getApiBaseUrl } from '../../support/environments';
import { expect } from 'playwright/test';

Given('ich rufe die abrechenbare Nachzahlung API mit VSNR auf', function (this: ICustomWorld) {
  this.requestPath = 'nachzahlungen/abrechenbare?vsnr=';
});
When(
  'ich einen GET Request an die URL für abrechenbare Nachzahlungen mit der VSNR {} und KTAN 70 absende',
  async function (this: ICustomWorld, VSNR: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
        'drv-mandant': '70', 
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 
      },
      json: true,
    };
console.log(this.accessToken);
    try {
      this.requestResponse = await this.requestContext?.get(
        `${getApiBaseUrl()}/${this.requestPath}${VSNR}`,
        options,
      );
      console.log(this.requestResponse);
    } catch (error) {
      console.error('Fehler bei der API-GET-Anfrage:', error);
      throw error;
    }
  },
);
When(
  'ich einen GET Request an die URL für abrechenbare Nachzahlungen mit der VSNR {} und KTAN 17 absende',
  async function (this: ICustomWorld, VSNR: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
        'drv-mandant': '17', 
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 
      },
      json: true,
    };
console.log(this.accessToken);
    try {
      this.requestResponse = await this.requestContext?.get(
        `${getApiBaseUrl()}/${this.requestPath}${VSNR}`,
        options,
      );
      console.log(this.requestResponse);
    } catch (error) {
      console.error('Fehler bei der API-GET-Anfrage:', error);
      throw error;
    }
  },
);
Then(
  'sollte ich eine 200 Antwort für abrechenbare Nachzahlungen erhalten',
  async function (this: ICustomWorld) {
    const responseStatus = this.requestResponse?.status();
    expect(responseStatus).toBe(200);
    }
);

Then('die Antwort sollte eine leere Liste sein', async function (this: ICustomWorld) {
  if (!this.requestResponse) {
    throw new Error('response ist undefined');
  }
  const body = await this.requestResponse?.json();
  expect(body).toEqual({"resourcen": [], "size": 0});
});

Then('die Antwort sollte mit einem gültigen Nachzahlungsbody sein', async function (this: ICustomWorld) {
    const responseStatus = this.requestResponse?.status();
    expect(responseStatus).toBe(200);
    if (responseStatus === 200) {
        const buffer = await this.requestResponse?.body();
        const result = JSON.parse(buffer!.toString());

        expect(result).toHaveProperty('resourcen');
        expect(Array.isArray(result.resourcen)).toBe(true);

        if (result.resourcen.length > 0) {
            const resourcen = result.resourcen[0];
            expect(resourcen).toHaveProperty('vorgangsId');
            expect(resourcen).toHaveProperty('bescheiddatum');
            expect(resourcen).toHaveProperty('nachzahlungsbetragGesamt');
            expect(resourcen).toHaveProperty('status', 'ABHOLBEREIT'); 

            expect(typeof resourcen.vorgangsId).toBe('string');
            expect(typeof resourcen.nachzahlungsbetragGesamt).toBe('number');
            expect(resourcen.status).toBe('ABHOLBEREIT');
        }
    }
});
