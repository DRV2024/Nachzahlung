/* eslint-disable indent */
/* eslint-disable prettier/prettier */
import { createNachzahlungenTF48POST } from '../../data/requestBody_NachzahlungenPOST_TF48';
import { createBodyNachzahlungenPOST } from '../../data/requestBody_NachzahlungenPOST';
import { createMehrereNachzahlungseintraegen } from '../../data/requestBody_mehrereNachzahlungseintraegen';
import { createNachzahlungMitMehrereZeitraueme } from '../../data/nachzahlungMitMehrereNachzahlungzeitraueme';
import { createBodyNachzahlungenPOSTWithInvalidDateRange } from '../../data/requestBody_NachzahlungenPOSTWithInvalidDateRange';
import { createNachzahlungMitMehrereErstattungsforderungen } from '../../data/nachzahlungMitMehrereErstattungsforderungen';
import { createNachzahlungMitMehrereForderungsZeitraeume } from '../../data/nachzahlungMitMehrereForderungszeitraeume';
import { createMismatchedNachzahlung } from '../../data/nachzahlungMitNichtUebereinstimmendenVorgangsIds';
import{createNachzahlungWithOverlappingForderungsZeitraeume} from '../../data/nachzahlungWithOverlappingForderungszeitraeume';
import{createNachzahlungWithOverlappingNachzahlungsZeitraeume} from '../../data/nachzahlungWithOverlappingNachzahlungszeitraeume';
import { ICustomWorld } from '../../support/custom-world';
import { getApiBaseUrl } from '../../support/environments';
import { getBestandsToken } from '../general.steps';
import { Given, When } from '@cucumber/cucumber';
import { randomUUID } from 'crypto';

export function generateVorgangsId(): string {
  return randomUUID();
}
function createRequestOptions(accessToken: string | undefined, ktan: string = '70'): Record<string, unknown> {
  if (!accessToken) {
    throw new Error('Access token is undefined');
  }

  return {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Bestand-Authorization':`Bearer ${getBestandsToken()}`,
      'Content-Type': 'application/json',
      'drv-mandant': ktan,
      'Accept': 'application/json',
      'Accept-Charset': 'utf-8',
    }
  };
}
Given('ich einen Post Request für Nachzahlung mit dynamisch generierten VorgangsId, Zeitraum, Rentenbeginn und anderen Daten und KTAN 17 absende', async function (this: ICustomWorld) {
  const vorgangsId = generateVorgangsId();
  const options = createRequestOptions(this.accessToken, '17');
  this.requestResponse = await this.requestContext?.post(
    `${getApiBaseUrl()}/${this.requestPath}`,
    {
      ...options,
      data: createNachzahlungenTF48POST(vorgangsId),
    }
  );

  if (this.requestResponse && this.requestResponse.ok()) {
    const ResponseData = await this.requestResponse.json();
    if (ResponseData.resourcen && ResponseData.resourcen.length > 0 && ResponseData.resourcen[0].vorgangsId) {
      this.generatedVorgangsId = ResponseData.resourcen[0].vorgangsId;
    } else {
      throw new Error('VorgangsId not found in response');
    }
  } else {
    throw new Error('Request failed');
  }
});

Given('ich keinen request body für die Nachzahlungen habe', function (this: ICustomWorld) {
  this.requestBody = null;
});

When(
  'ich einen POST Request mit einer existierenden VorgangsId = {} und KTAN {} absende',
  async function (this: ICustomWorld, vorgangsId: string, ktan: string) {
    const options = createRequestOptions(this.accessToken, ktan);
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}`,
      {
        ...options,
        data: createBodyNachzahlungenPOST(vorgangsId),
      },
    );
  },
);
When(
  'ich einen Post Request für Nachzahlungen mit einer dynamisch generierten VorgangsId und KTAN 70 absende',
  async function (this: ICustomWorld) {
    const vorgangsId = generateVorgangsId();
    const options = createRequestOptions(this.accessToken);
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}`,
      {
        ...options,
        data: createBodyNachzahlungenPOST(vorgangsId),
      },
    );
  },
);
When(
  'ich {} Post Requests für Nachzahlungen mit einer dynamisch generierten VorgangsId und KTAN 70 absende',
  async function (this: ICustomWorld, count: number) {
    const options = createRequestOptions(this.accessToken);

    const resourcen = [];
    for (let i = 0; i < count; i++) {
      const vorgangsId = generateVorgangsId();
      resourcen.push(createMehrereNachzahlungseintraegen(vorgangsId));
    }
    const payload = {resourcen};
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}`,
      {
        ...options,
        data: payload ,
      },
    );
  },
);
When(
  'ich einen POST Request mit falschem Format für Nachzahlungen mit einer dynamisch generierten VorgangsId und KTAN 70 absende',
  async function (this: ICustomWorld) {
    const vorgangsId = generateVorgangsId();

    const body = {
      resourcen: [
        {
          vorgangsId: vorgangsId,
          ungueltigesFeld: 'Ungültiger Wert',
        },
      ],
    };

    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
        'drv-mandant': '70', 
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8', 
      },
    };

    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}`,
      {
        ...options,
        data: body,
      },
    );
  },
);
When(
  'ich einen POST Request mit falschem Format an die URL für Nachzahlungen mit der VorgangsId = {} absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'content-Type': 'application/json',
      },
      data: {
        antrag: '2022-03-16',
      },
    };
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options,
    );
    console.log('HTTP Response: ', this.requestResponse);
  },
);
When(
  'ich einen POST Request an eine nicht vorhandene VorgangsId = {} absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
      },
      json: true,
      data: {
        eingangsdatumRentenantrag: '2021-03-14',
      },
    };
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options,
    );
  },
);
When(
  'ich einen POST Request an die URL für Nachzahlungen mit der VorgangsId = {} absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
      },
      json: true,
      data: {
        eingangsdatumRentenantrag: '2021-03-14',
      },
    };
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options,
    );
  },
);

When(
  'ich einen POST Request mit zu vielen Attributen an die URL für Nachzahlungen mit der VorgangsId = {} absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      {
        data: {
          eingangsdatumRentenantrag: '2022-03-12',
          zusätzlichesAttribut: 'zusätzlicher Wert',
        },
      },
    );
  },
);
When(
  'ich einen POST Request mit unsupported Media Type an die URL für Nachzahlungen mit der VorgangsId = {} absende',
  async function (this: ICustomWorld, vorgangsId: string) {
    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'text/plain', // Falscher Content-Type
      },

      // json: true entfernen, da dies den Content-Type auf application/json setzen würde
      data: 'eingangsdatumRentenantrag=2022-03-16', // Kein JSON, nur Text
    };

    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}/${vorgangsId}`,
      options,
    );

    console.log('HTTP Response: ', this.requestResponse);
  },
);
When(
  'ich einen POST-Request mit einem nicht unterstützten Medientyp für Nachzahlungen mit einer dynamisch generierten Vorgangs-ID und KTAN 70 absende',
  async function (this: ICustomWorld) {
    const vorgangsId = generateVorgangsId();

    const options = {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'text/plain',
        'drv-mandant': '70',
      },
    };

    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}`,
      {
        ...options,
        data: createBodyNachzahlungenPOST(vorgangsId),
      },
    );
  },
);
When(
  'ich eine Nachzahlung mit ungültigem Zeitraum und einer dynamisch generierten VorgangsId und KTAN 70 anfordere',
  async function (this: ICustomWorld) {
    const options = createRequestOptions(this.accessToken); // Verwendung der neuen Funktion
    const vorgangsId = generateVorgangsId();
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}`,
      {
        ...options,
        data: createBodyNachzahlungenPOSTWithInvalidDateRange(vorgangsId),
      },
    );
  },
);
When(
  'ich eine Nachzahlung mit {} Zeiträumen und einer dynamisch generierten VorgangsId und KTAN 70 anfordere',
  async function (this: ICustomWorld, count: number) {
    const options = createRequestOptions(this.accessToken);
    const vorgangsId = generateVorgangsId();

    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}`,
      {
        ...options,
        data: createNachzahlungMitMehrereZeitraueme(vorgangsId, count),
      },
    );
  },
);
When(
  'ich eine Nachzahlung mit {} Erstattungsforderungen und einer dynamisch generierten VorgangsId und KTAN 70 anfordere',
  async function (this: ICustomWorld, count: number) {
    const vorgangsId = generateVorgangsId();
    const options = createRequestOptions(this.accessToken);
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}`,
      {
        ...options,
        data: createNachzahlungMitMehrereErstattungsforderungen(vorgangsId, count),
      },
    );
  },
);
When(
  'ich eine Nachzahlung mit {} Forderungszeiträume und einer dynamisch generierten VorgangsId und KTAN 70 anfordere',
  async function (this: ICustomWorld, count: number) {
    const vorgangsId = generateVorgangsId();
    const options = createRequestOptions(this.accessToken);
    this.requestResponse = await this.requestContext?.post(
      `${getApiBaseUrl()}/${this.requestPath}`,
      {
        ...options,
        data: createNachzahlungMitMehrereForderungsZeitraeume(vorgangsId, count),
      },
    );
  },
);
When('ich eine Nachzahlung mit nicht übereinstimmenden dynamisch generierten VorgangsIds und KTAN 70 für "{}" anfordere', async function (this: ICustomWorld, scenario) {
    const options = createRequestOptions(this.accessToken);
  this.requestResponse = await this.requestContext?.post(
    `${getApiBaseUrl()}/${this.requestPath}`,
    {
      ...options,
      data: createMismatchedNachzahlung(scenario),
         },
    );
  },
);
When('ich mit überlappenden ForderungsZeiträumen und KTAN 70 eine Nachzahlung anfordere', async function (this: ICustomWorld) {
    const vorgangsId = generateVorgangsId();
    const nachzahlungData = createNachzahlungWithOverlappingForderungsZeitraeume(vorgangsId);
    const options = createRequestOptions(this.accessToken);
  this.requestResponse = await this.requestContext?.post(
    `${getApiBaseUrl()}/${this.requestPath}`,
    {
      ...options,
      data: nachzahlungData         },
    );
  },
);
When('ich mit überlappenden Nachzahlungszeiträume und KTAN 70 eine Nachzahlung anfordere', async function (this: ICustomWorld) {
    const vorgangsId = generateVorgangsId();
    const nachzahlungData = createNachzahlungWithOverlappingNachzahlungsZeitraeume(vorgangsId);
    const options = createRequestOptions(this.accessToken);
  this.requestResponse = await this.requestContext?.post(
    `${getApiBaseUrl()}/${this.requestPath}`,
    {
      ...options,
      data: nachzahlungData         },
    );
  },
);
