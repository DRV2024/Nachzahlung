import { ICustomWorld } from '../support/custom-world';
import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Given('eine ungültige URL', async function (this: ICustomWorld) {
  await this.seitenFehler?.openUngueltigeUrl('12');
});

Given('die geöffnete Seite Page not found', async function (this: ICustomWorld) {
  expect(await this.seitenFehler?.getPageNotFoundTitle()).toEqual(
    'Ups, diese Seite will wohl nicht gefunden werden.',
  );
});

When('die Sachbearbeitung eine ungültige URL wählt', async function (this: ICustomWorld) {
  await this.seitenFehler?.openUngueltigeUrl('12');
});

Then('öffnet sich die Seite Page not found', async function (this: ICustomWorld) {
  expect(await this.seitenFehler?.getPageNotFoundTitle()).toEqual(
    'Ups, diese Seite will wohl nicht gefunden werden.',
  );
});

Then('wird der Sachbearbeitung die Fehler-Seite angezeigt', async function (this: ICustomWorld) {
  const page = this.page!;
  const actualHeadline = await page.locator('h3').textContent();
  expect(actualHeadline).toEqual('Hoppala, da ist ein Fehler aufgetreten');
});
