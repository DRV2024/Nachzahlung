import { ICustomWorld } from '../support/custom-world';
import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

When(
  'die Sachbearbeitung das Antragsdatum mit {} ausfüllt',
  async function (this: ICustomWorld, value: string) {
    await this.antragEingang?.setAntragEingangDatum(value);
  },
);

/*Then(
  'sieht die Sachbearbeitung das folgende Antragsdatum - {}',
  async function (this: ICustomWorld, antragsDatum: string) {
    await expect(this.antragEingang?.getAntragsDatum()).toEqual(antragsDatum);
  },
);*/

/*Then(
  'wird der Sachbearbeitung das Datum der vollständigen Antragstellung angezeigt',
  async function (this: ICustomWorld) {
    const page = this.page!;
    await expect(page.locator('#antragEingangInput')).toBeVisible();
  },
);*/

Then(
  'erwarte ich das Antragsdatum - {}',
  async function (this: ICustomWorld, eingangsDatum: string) {
    const page = this.page!;
    const antragsDatum = await page
      .locator(
        'body > app-root > div > div > app-main > app-nachzahlung > div > app-antragsdatum-aenderung > div > p:nth-child(4) > b',
      )
      .innerText();
    await expect(antragsDatum).toEqual(eingangsDatum);
    await expect(page.locator('#abschlussBtn')).toBeEnabled();
  },
);

Then(
  'erwarte ich die Fehlermeldung: {}',
  async function (this: ICustomWorld, fehlermeldung: string) {
    await expect(await this.antragEingang?.getAntragEingangError()).toEqual(fehlermeldung);
  },
);
