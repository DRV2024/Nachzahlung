import { ICustomWorld } from '../support/custom-world';
import { When } from '@cucumber/cucumber';

When(
  'die Sachbearbeitung füllt das Antragseingangsdatum {}',
  async function (this: ICustomWorld, rentenantragsdatum: string) {
    await this.antragsdatumAenderung?.setRentenantragsdatum(rentenantragsdatum);
  },
);
