import { ICustomWorld } from '../support/custom-world';
import { config } from '../support/config';
import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
// import { privateDecrypt } from 'crypto';

When(
  'die Sachbearbeitung Adressschlüssel mit {} ausfüllt',
  async function (this: ICustomWorld, value: string) {
    await this.erstattungsanspruchForm?.setAdressschlüssel(value);
  },
);

When(
  'die Sachbearbeitung Bezeichnung der erstattungsberechtigten Stelle mit {} ausfüllt',
  async function (this: ICustomWorld, value: string) {
    await this.erstattungsanspruchForm?.setErstattungsBerechtigteStelle(value);
  },
);

When(
  'die Sachbearbeitung rvPur-Nummer mit {} ausfüllt',
  async function (this: ICustomWorld, value: string) {
    await this.erstattungsanspruchForm?.setRvPurNummer(value);
  },
);

When(
  'die Sachbearbeitung Aktenzeichen mit {} ausfüllt',
  async function (this: ICustomWorld, value: string) {
    await this.erstattungsanspruchForm?.setAktenzeichen(value);
  },
);

When(
  'die Sachbearbeitung Erstattungsanspruch mit {} ausfüllt',
  async function (this: ICustomWorld, value: string) {
    if (value === 'Ja') {
      await this.erstattungsanspruchForm?.setErstattungGeltendMachen('ja');
    } else {
      await this.erstattungsanspruchForm?.setErstattungGeltendMachen('Nein');
    }
  },
);

When(
  'die Sachbearbeitung Buchungszeichen mit {} ausfüllt',
  async function (this: ICustomWorld, value: string) {
    await this.erstattungsanspruchForm?.setBuchungszeichen(value);
  },
);

When(
  'die Sachbearbeitung Rechtsgrundlage mit {} ausfüllt',
  async function (this: ICustomWorld, value: string) {
    await this.erstattungsanspruchForm?.setRechtsgrundlage(value);
  },
);

When(
  'die Sachbearbeitung das {int}. Von-Datum mit {} ausfüllt',
  async function (this: ICustomWorld, nth: number, value: string) {
    await this.erstattungsanspruchForm?.setStartdatum(value, --nth);
  },
);

When(
  'die Sachbearbeitung das {int}. Bis-Datum mit {} ausfüllt',
  async function (this: ICustomWorld, nth: number, value: string) {
    await this.erstattungsanspruchForm?.setEnddatum(value, --nth);
  },
);

When(
  'die Sachbearbeitung die Höhe der {int}. Forderung mit {} ausfüllt',
  async function (this: ICustomWorld, nth: number, value: string) {
    await this.erstattungsanspruchForm?.setBetragForderung(value, --nth);
  },
);

When('die Sachbearbeitung den Eintrag speichert', async function (this: ICustomWorld) {
  await this.erstattungsanspruchForm?.saveForderung();
  await this.page?.waitForTimeout(config.timeout.short);
});

When(
  'die Sachbearbeitung den Forderungszeitraum Nr. {} löscht',
  async function (this: ICustomWorld, param: string) {
    const nummer: number = +param;
    await this.erstattungsanspruchForm?.deleteZeitraum(nummer);
  },
);
When(
  'die Sachbearbeitung einen anderen neuen Zeitraum hinzufügt',
  async function (this: ICustomWorld) {
    await this.erstattungsanspruchForm?.addZeitraum();
  },
);
When(
  'die Sachbearbeitung füllt den {int} Zeitraum',
  async function (this: ICustomWorld, zeitRaumNummer: number, table) {
    const data = table.hashes()[0];
    await this.erstattungsanspruchForm?.fillZeitraum(
      zeitRaumNummer,
      data.Startdatum,
      data.Enddatum,
      data.BetragForderung,
    );
  },
);
When('die Sachbearbeitung löscht alle Felder', async function () {
  await this.erstattungsanspruchForm?.clearFields();
});

When('die Sachbearbeitung füllt eine Forderung', async function (this: ICustomWorld, table) {
  const data = table.hashes()[0]; // Diese Methode tabel.hasehs() wandelt die 'DataTable in cucumber in ein Array [{name: 'jürgen', vorname: 'müller'}]

  await this.erstattungsanspruchForm?.fillForderung(
    data.Adressschlüssel,
    data.ErstattungsBerechtigteStelle,
    data.RvPurNummer,
    data.Aktenzeichen,
    data.ErstattungGeltendMachen,
    data.Buchungszeichen,
    data.Rechtsgrundlage,
    data.Startdatum,
    data.Enddatum,
    data.BetragForderung,
    data.Rangfolge,
  );
});

When(
  'die Sachbearbeitung macht eine Erstattungsforderung nicht geltend',
  async function (this: ICustomWorld, table) {
    const data = table.hashes()[0];

    await this.erstattungsanspruchForm?.fillForderungErstattungGeltendMachenNein(
      data.Adressschlüssel,
      data.ErstattungsBerechtigteStelle,
      data.RvPurNummer,
      data.Aktenzeichen,
      data.ErstattungGeltendMachen,
    );
  },
);
When(
  'die Sachbearbeitung macht eine Erstattungsforderung geltend',
  async function (this: ICustomWorld) {
    await this.erstattungsanspruchForm?.setErstattungGeltendMachenJa();
  },
);
When(
  'die Sachbearbeitung wählt die Rechtsgrundlage {} aus',
  async function (this: ICustomWorld, rechtsgrundlage: string) {
    await this.erstattungsanspruchForm?.setRechtsgrundlage(rechtsgrundlage);
  },
);
When(
  'die Sachbearbeitung wählt die Rangfolge {} aus',
  async function (this: ICustomWorld, rangfolge: string) {
    await this.erstattungsanspruchForm?.setRang(rangfolge);
  },
);
When(
  'die Sachbearbeitung klickt bei Erstattungsforderung geltend gemacht auf Nein',
  async function (this: ICustomWorld) {
    await this.erstattungsanspruchForm?.setErstattungGeltendMachenNein();
  },
);

When(
  'die Sachbearbeitung alle Felder einer Forderung gültig befüllt',
  async function (this: ICustomWorld) {
    // await this.erstattungsanspruchForm?.fillForderungValid();
    await this.erstattungsanspruchForm?.fillForderung(
      'R80',
      'Knappschaft',
      '00037',
      '234567',
      'Ja',
      '123456',
      '103',
      '01',
      '31',
      '430,00',
      '1',
    );
  },
);

When(
  'die Sachbearbeitung mit der Tabulatortaste zur Schaltfläche Verwerfen navigiert',
  async function (this: ICustomWorld) {
    await this.erstattungsanspruchForm?.skipForwardModal();
  },
);

When(
  'die Sachbearbeitung mit der Shift- und Tabulatortaste zur Schaltfläche Weiteren Zeitraum hinzufügen navigiert',
  async function (this: ICustomWorld) {
    await this.erstattungsanspruchForm?.skipBackwardModal();
  },
);

When('die Sachbearbeitung die Entertaste betätigt', async function (this: ICustomWorld) {
  await this.erstattungsanspruchForm?.pressEnter();
});

Then(
  'werden die folgenden Anspruchsdaten angezeigt: {}, {}, {}',
  async function (
    this: ICustomWorld,
    adressschluessel: string,
    nameErstattungsstelle: string,
    aktenzeichen: string,
  ) {
    await expect([
      await this.erstattungsanspruchForm?.getAdresschlüssel(),
      await this.erstattungsanspruchForm?.getErstattungsstelle(),
      await this.erstattungsanspruchForm?.getAktenzeichen(),
    ]).toEqual([adressschluessel, nameErstattungsstelle, aktenzeichen]);
  },
);

Then('kann die Sachbearbeitung die Forderung nicht speichern', async function (this: ICustomWorld) {
  const page = this.page!;
  await expect(page.locator('#saveBtn')).toBeDisabled;
});

Then('kann die Sachbearbeitung die Forderung speichern', async function (this: ICustomWorld) {
  const page = this.page!;
  await expect(page.locator('#saveBtn')).toBeEnabled;
});

Then(
  'kann die Sachbearbeitung den {int}. Forderungszeitraum eingeben',
  async function (this: ICustomWorld, nth: number) {
    expect(await this.erstattungsanspruchForm?.getZeitraumLabel(--nth)).toEqual(
      nth + 1 + '. Forderungszeitraum',
    );
  },
);

Then('die Sachbearbeitung verwirft die Forderung', async function (this: ICustomWorld) {
  await this.erstattungsanspruchForm?.clickCancel();
});

Then(
  'es erscheint die Fehlermeldung für Feld {} "{}"',
  async function (this: ICustomWorld, feld: string, fehlermeldung: string) {
    if (feld === 'NotificationTitle') {
      expect(await this.erstattungsanspruchForm?.getNotificationTitle()).toEqual(fehlermeldung);
    } else if (feld === 'ErrorMessageAdressschlüssel') {
      expect(await this.erstattungsanspruchForm?.getErrorMessageAdressschlüssel()).toEqual(
        fehlermeldung,
      );
    } else if (feld === 'ErrorMessageErstattungsBerechtigteStelle') {
      expect(
        await this.erstattungsanspruchForm?.getErrorMessageErstattungsBerechtigteStelle(),
      ).toEqual(fehlermeldung);
    } else if (feld === 'ErrorMessageAktenzeichen') {
      expect(await this.erstattungsanspruchForm?.getErrorMessageAktenzeichen()).toEqual(
        fehlermeldung,
      );
    } else if (feld === 'ErrorMessageDokumentNr') {
      expect(await this.erstattungsanspruchForm?.getErrorMessageDokumentNr()).toEqual(
        fehlermeldung,
      );
    } else if (feld === 'ErrorMessageStartdatum') {
      expect(await this.erstattungsanspruchForm?.getErrorMessageStartdatum()).toEqual(
        fehlermeldung,
      );
    } else if (feld === 'ErrorMessageEnddatum') {
      expect(await this.erstattungsanspruchForm?.getErrorMessageEnddatum()).toEqual(fehlermeldung);
    } else if (feld === 'ErrorMessageBetragForderung') {
      expect(await this.erstattungsanspruchForm?.getErrorMessageBetragForderung()).toEqual(
        fehlermeldung,
      );
    } else if (feld === 'ErrorMessage') {
      expect(await this.erstattungsanspruchForm?.getErrorMessage()).toEqual(fehlermeldung);
    } else if (feld === 'ErrorMessage1') {
      expect(await this.erstattungsanspruchForm?.getErrorMessage1()).toEqual(fehlermeldung);
    }
  },
);

Then(
  'es erscheint die Fehlermeldung "{}" zum {int}. Von-Datum',
  async function (this: ICustomWorld, fehlermeldung: string, nth: number) {
    await expect(await this.erstattungsanspruchForm?.getZeitraumVomError(--nth)).toEqual(
      fehlermeldung,
    );
  },
);

Then(
  'es erscheint die Fehlermeldung "{}" zum {int}. Bis-Datum',
  async function (this: ICustomWorld, fehlermeldung: string, nth: number) {
    await expect(await this.erstattungsanspruchForm?.getZeitraumBisError(--nth)).toEqual(
      fehlermeldung,
    );
  },
);

Then('erwarte ich die Meldung über die {}', async function (this: ICustomWorld, herkunft: string) {
  if (herkunft == 'manuelle Herkunft') {
    await expect(await this.erstattungsanspruchForm?.getForderungManuellLabel()).toEqual(
      'Sie sind im Begriff einen Eintrag zu bearbeiten, der manuell hinzugefügt wurde.',
    );
  } else if (herkunft == 'maschinelle Herkunft') {
    await expect(await this.erstattungsanspruchForm?.getForderungMaschinellLabel()).toEqual(
      'Sie sind im Begriff einen Eintrag zu bearbeiten, der maschinell übertragen wurde.',
    );
  } else {
    await expect(await this.erstattungsanspruchForm?.getForderungMaschinellManuellLabel()).toEqual(
      'Dieser Eintrag wurde maschinell übertragen. Es wurden aber bereits manuelle Änderungen durchgeführt.',
    );
  }
});

Then(
  'erwarte ich, dass {} neben dem Warnungstext sichtbar ist',
  async function (this: ICustomWorld, herkunft: string) {
    if (herkunft == 'das Maschinell-Icon') {
      await expect(
        await this.erstattungsanspruchForm!.getForderungAnspruchMaschinellIcon(),
      ).toBeVisible();
    } else if (herkunft == 'das Manuell-Icon') {
      await expect(
        await this.erstattungsanspruchForm!.getForderungAnspruchManuellIcon(),
      ).toBeVisible();
    } else {
      await expect(
        await this.erstattungsanspruchForm!.getForderungAnspruchMaschinellIcon(),
      ).toBeVisible();
      await expect(
        await this.erstattungsanspruchForm!.getForderungAnspruchManuellIcon(),
      ).toBeVisible();
    }
  },
);

Then('erwarte ich, dass das Maschinell-Icon rot ist.', async function (this: ICustomWorld) {
  await expect(
    await this.erstattungsanspruchForm!.getForderungAnspruchMaschinellIcon(),
  ).toHaveClass(/label--red-override/);
});

Then(
  'erwarte ich, dass die Meldung über die Herkunft des Erstattungsanspruchs rot ist.',
  async function (this: ICustomWorld) {
    const page = this.page!;
    await expect(page.locator('#herkunftForderungMaschinellLabel')).toHaveClass(
      /label--red-override/,
    );
  },
);

Then('schließt sich das Eingabe-Modal', async function (this: ICustomWorld) {
  const page = this.page!;
  await expect(page.locator('#eingabeModal')).toBeHidden;
});
Then('erwarte ich die Anzeige der Rangfolgeauswahl', async function (this: ICustomWorld) {
  const fieldRangfolge = await this.erstattungsanspruchForm?.getfieldRangfolge();
  if (fieldRangfolge) {
    await expect(fieldRangfolge).toBeVisible();
  }
});
Then('ist Radiobutton auf Rang 1 markiert', async function (this: ICustomWorld) {
  const rang1 = await this.erstattungsanspruchForm?.getRang1();
  if (rang1) {
    await expect(rang1).toBeChecked();
    await expect(rang1).toBeVisible();
  } else {
    throw new Error('Fehler bei der Markierung');
  }
});
Then('wird die geänderte Rangfolge gespeichert', async function (this: ICustomWorld) {
  const rang2 = await this.erstattungsanspruchForm?.getRang2();
  if (rang2) {
    await expect(rang2).toBeChecked();
    await expect(rang2).toBeVisible();
  } else {
    throw new Error('Fehler bei der Markierung');
  }
});
