import { ICustomWorld } from '../support/custom-world';
import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

Given(
  'die geöffnete Nachzahlungsübersichtsseite für den Versicherten mit VorgangsId = {}',
  async function (this: ICustomWorld, VorgangsId: string) {
    await this.vorhandeneNachzahlungen?.openNachzahlungsübersicht(VorgangsId);
  },
);
Given(
  'die geöffnete Nachzahlungsübersichtsseite für den Versicherten mit der VSNR = {}',
  async function (this: ICustomWorld, VSNR: string) {
    await this.vorhandeneNachzahlungen?.openNachzahlungsübersicht(VSNR);
  },
);
Given(
  'die geöffnete Seite mit Nachzahlungen und Ansprüchen für die Vorgangsid = {}',
  async function (this: ICustomWorld, nachzahlung_id: string) {
    await this.vorhandeneNachzahlungen?.openAnspruchsseite(nachzahlung_id);
  },
);
Given(
  'die geöffnete Seite mit Nachzahlungen und Ansprüchen für die generierte VorgangsId',
  async function (this: ICustomWorld) {
    if (!this.generatedVorgangsId) {
      throw new Error('No generated VorgangsId found');
    }
    await this.vorhandeneNachzahlungen?.openAnspruchsseite(this.generatedVorgangsId);
  },
);
Given(
  'die geöffnete Nachzahlungsübersichtsseite für den Versicherten mit einer Nachzahlung',
  async function (this: ICustomWorld) {
    await this.vorhandeneNachzahlungen?.openNachzahlungsübersicht('0120');
  },
);

Given(
  'die geöffnete Nachzahlungsübersichtsseite für den Versicherten mit mehreren Nachzahlungen',
  async function (this: ICustomWorld) {
    // await this.vorhandeneNachzahlungen?.openNachzahlungsübersicht('0123'); dev
    await this.vorhandeneNachzahlungen?.openNachzahlungsübersicht('28280158N017'); //demo
  },
);
Given(
  'die Sachbearbeitung öffnet die {}. Vorhandene Nachzahlung = {}',
  async function (this: ICustomWorld, nr: number, nachzahlung_id: string) {
    await this.vorhandeneNachzahlungen?.öffneVorhandeneNachzahlung(nr, nachzahlung_id);
  },
);

When(
  'die Sachbearbeitung die Nachzahlung Nr. {} in der Tabelle auswählt',
  async function (this: ICustomWorld, param: string) {
    const nummer: number = +param;
    await this.vorhandeneNachzahlungen?.selectNachzahlung(nummer);
  },
);
Then(
  'öffnet sich die Seite mit allen vorhandenen Nachzahlungen als Tabelle',
  async function (this: ICustomWorld) {
    for (let i = 0; i < 2; i++) {
      const nachzahlungUebersichtRentenberechtigtePerson =
        await this.vorhandeneNachzahlungen?.getNachzahlungUebersichtRentenberechtigtePerson(i);
      expect(nachzahlungUebersichtRentenberechtigtePerson).toMatch(
        /Zwei, Nachzahlungen|Brot, Bernd/,
      );
    }
  },
);

When(
  'ich die Nachzahlung an Stelle {} für die LEAT {} und die Nachzahlung an Stelle {} für die LEAT {} miteinander vergleiche',
  async function (
    this: ICustomWorld,
    stelleA: string,
    ersteNachzahlung: string,
    stelleB: string,
    zweiteNachzahlung: string,
  ) {
    const nummerA: number = +stelleA;
    const nummerB: number = +stelleB;
    const erste = await this.vorhandeneNachzahlungen?.getLeistungsart(nummerA);
    const zweite = await this.vorhandeneNachzahlungen?.getLeistungsart(nummerB);
    expect(erste).toEqual(ersteNachzahlung);
    expect(zweite).toEqual(zweiteNachzahlung);
  },
);

Then(
  'erwarte ich, dass die Nachzahlung an Stelle {} ein kleineres Bescheiddatum hat als die Nachzahlung an Stelle {}',
  async function (this: ICustomWorld, stelleA: string, stelleB: string) {
    const nummerA: number = +stelleA;
    const nummerB: number = +stelleB;
    const datum1 = await this.vorhandeneNachzahlungen?.getBescheiddatum(nummerA);
    const datum2 = await this.vorhandeneNachzahlungen?.getBescheiddatum(nummerB);
    const [tag1, monat1, jahr1] = datum1!.split('.');
    const [tag2, monat2, jahr2] = datum2!.split('.');
    const date1 = new Date(parseInt(jahr1), parseInt(monat1) - 1, parseInt(tag1));
    const date2 = new Date(parseInt(jahr2), parseInt(monat2) - 1, parseInt(tag2));
    expect(date1.getTime()).toBeLessThan(date2.getTime());
  },
);
Then(
  'erwarte ich, dass die Nachzahlungsübersichtsseite keine Nachzahlungen enthält',
  async function (this: ICustomWorld) {
    const nachzahlungenVorhanden = await this.page?.locator('.drv-linklist li').isVisible();
    expect(nachzahlungenVorhanden).toBe(false);
  },
);
