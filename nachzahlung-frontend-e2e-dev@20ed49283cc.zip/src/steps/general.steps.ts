import { ICustomWorld } from '../support/custom-world';
import { getBestandsPrivateKey } from '../support/config';
import { Given, Then } from '@cucumber/cucumber';
import { Page, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import type { Response } from 'playwright-core';
import { sign } from 'jsonwebtoken';
// eslint-disable-next-line @typescript-eslint/no-var-requires
const htmlValidator = require('html-validator');
let bestandsToken = '';

function getResponsesByHtmlRequest(responses: Response[]) {
  return responses.filter((res: Response) => res.request().url().includes('.html'));
}

async function clearBrowserCache(page: Page) {
  await page.route('**', (route) => route.continue());
}
Given(
  'die Sachbearbeitung ist als {} in Mandant {} eingeloggt',
  async function (userType: string, mandant: string) {
    await this.loginPage?.login(mandant, userType);
  },
);
Given('ein aktives Monitoring der HTTP-Requests des Browsers', async function (this: ICustomWorld) {
  await clearBrowserCache(this.page!);
  this.tracedResponses = [];
  this.page?.on('response', (response: any) => this.tracedResponses?.push(response));
});
Given(
  'ich habe ein gueltiges Bestands-Token zur VSNR {}, DRV-Id {} und KTAN {}',
  async function (this: ICustomWorld, vsnr: string, drvId: string, ktan: string) {
    bestandsToken = sign(
      {
        aud: 'modern',
        drvid: drvId,
        vsnr: vsnr,
        drv_mandant: ktan,
        exp: Math.floor(Date.now() / 1000) + 60 * 60,
      },
      getBestandsPrivateKey(),
      {
        algorithm: 'ES256',
        issuer: 'TEST',
      },
    );
  },
);
Given(
  'ich habe ein ungueltiges Bestands-Token zur VSNR {}, DRV-Id {} und KTAN {}',
  async function (this: ICustomWorld, vsnr: string, drvId: string, ktan: string) {
    bestandsToken = sign(
      {
        aud: 'modern',
        drvid: drvId,
        vsnr: vsnr,
        drv_mandant: ktan,
        exp: Math.floor(Date.now() / 1000) - 60 * 60, //Ablaufdatum in der Vergangenheit
      },
      getBestandsPrivateKey(),
      {
        algorithm: 'ES256',
        issuer: 'TEST',
      },
    );
  },
);
Given('ich habe kein rvDialog-Token', async function (this: ICustomWorld) {
  bestandsToken = '';
});

Then(
  'erwarte ich einen sicheren access-control-allow-origin Header der Web-Page für den Versicherten',
  async function (this: ICustomWorld) {
    const relevantRequests = getResponsesByHtmlRequest(this.tracedResponses!);
    for (const entry of relevantRequests) {
      const headers = await entry.allHeaders();
      console.log(headers);
      const CORSHeader = headers['access-control-allow-origin'];
      expect(CORSHeader).toBeTruthy();
      expect(CORSHeader.toLowerCase()).toBe(
        'https://nzv-frontend-dev.apps.os-evo.entw.bund.drv/nachzahlungen?vsnr=28280158N017',
      );
    }
  },
);
Then(
  'erwarte ich einen sicheren access-control-allow-origin Header der Web-Page für diese VorgangsId',
  async function (this: ICustomWorld) {
    const relevantRequests = getResponsesByHtmlRequest(this.tracedResponses!);
    for (const entry of relevantRequests) {
      const headers = await entry.allHeaders();
      console.log(headers);
      const CORSHeader = headers['access-control-allow-origin'];
      expect(CORSHeader).toBeTruthy();
      expect(CORSHeader.toLowerCase()).toBe(
        'https://nzv-frontend-dev.apps.os-evo.entw.bund.drv/nachzahlungen/00000000-0000-0000-0003-000000000003',
      );
    }
  },
);

Then(
  'erwarte ich einen gesetzten content-security-policy Header der Web-Page',
  async function (this: ICustomWorld) {
    const relevantRequests = getResponsesByHtmlRequest(this.tracedResponses!);
    for (const entry of relevantRequests) {
      const headers = await entry.allHeaders();
      console.log(headers);
      expect(headers['content-security-policy']).toBeTruthy();
    }
  },
);

Then(
  'erwarte ich einen sicheren x-frame-options Header der Web-Page',
  async function (this: ICustomWorld) {
    const relevantRequests = getResponsesByHtmlRequest(this.tracedResponses!);
    for (const entry of relevantRequests) {
      const headers = await entry.allHeaders();
      const xFrameHeader = headers['x-frame-options'];
      expect(xFrameHeader).toBeTruthy();
      expect(xFrameHeader.toLowerCase()).toMatch(/^deny$|^sameorigin$/);
    }
  },
);

Then(
  'erwarte ich "{}" als content-type in der API-Antwort',
  async function (this: ICustomWorld, expectedContentType: number) {
    const headers = this.requestResponse?.headers();
    console.log('Received Headers: ', headers);
    expect(headers).toBeDefined();
    if (headers) {
      expect(headers!['content-type']).toEqual(expectedContentType);
    } else {
      throw new Error('Headers not found in the response');
    }
  },
);

Then(
  'erwarte ich einen sicheren x-frame-options Header in der API-Antwort',
  async function (this: ICustomWorld) {
    const xFrameHeader = this.requestResponse?.headers()['x-frame-options'];
    expect(xFrameHeader).toBeTruthy();
    expect(xFrameHeader?.toLowerCase()).toMatch(/^deny$|^sameorigin$/);
  },
);

Then('erwarte ich keine Server-Details in der API-Antwort', async function (this: ICustomWorld) {
  const serverHeader = this.requestResponse?.headers()['server'];
  if (!serverHeader) {
    // Wenn der Header nicht gesetzt wird, werden keine Informationen preisgegeben, daher ist der Test erfolgreich
    expect(serverHeader).toBeUndefined();
    return;
  }
  expect(serverHeader.toLowerCase()).not.toMatch(/nginx|tomcat/);
});

Then(
  'erwarte ich einen sicheren cache-control Header in der API-Antwort',
  async function (this: ICustomWorld) {
    const cacheControlHeader = this.requestResponse?.headers()['cache-control'];
    expect(cacheControlHeader).toBeTruthy();
    expect(cacheControlHeader?.toLowerCase()).toEqual('no-store');
  },
);

Then(
  'erwarte ich einen sicheren content-security-policy Header in der API-Antwort',
  async function (this: ICustomWorld) {
    const CSPHeader = this.requestResponse?.headers()['content-security-policy'];
    expect(CSPHeader).toBeTruthy();
    expect(CSPHeader?.toLowerCase()).toEqual("default-src 'none'; frame-ancestors 'none';");
  },
);

Then(
  'erwarte ich einen sicheren strict-transport-security Header in der API-Antwort',
  async function (this: ICustomWorld) {
    const strictTransportSecurityHeader =
      this.requestResponse?.headers()['strict-transport-security'];
    expect(strictTransportSecurityHeader).toBeTruthy();
    expect(strictTransportSecurityHeader?.toLowerCase()).toEqual(
      'max-age=63072000; includesubdomains; preload',
    );
  },
);

Then(
  'erwarte ich einen sicheren feature-policy Header in der API-Antwort',
  async function (this: ICustomWorld) {
    const featurePolicyHeader = this.requestResponse?.headers()['feature-policy'];
    expect(featurePolicyHeader).toBeTruthy();
    expect(featurePolicyHeader?.toLowerCase()).toEqual('none');
  },
);

Then(
  'erwarte ich einen sicheren referrer-policy Header in der API-Antwort',
  async function (this: ICustomWorld) {
    const referrerPolicyHeader = this.requestResponse?.headers()['referrer-policy'];
    expect(referrerPolicyHeader).toBeTruthy();
    expect(referrerPolicyHeader?.toLowerCase()).toEqual('no-referrer');
  },
);

Then(
  'erwarte ich einen sicheren x-content-type-option Header in der API-Antwort',
  async function (this: ICustomWorld) {
    const referrerPolicyHeader = this.requestResponse?.headers()['x-content-type-options'];
    expect(referrerPolicyHeader).toBeTruthy();
    expect(referrerPolicyHeader?.toLowerCase()).toEqual('nosniff');
  },
);

Then(
  'erwarte ich keine Barrierefreiheitsfehler auf dieser Seite',
  async function (this: ICustomWorld) {
    const page = this.page!;
    //wartet bis die Navigation abgeschlossen ist
    await page.waitForNavigation();
    //die Seite ist voll geladen
    await page.waitForLoadState('networkidle');
    const a11yScans = await new AxeBuilder({ page }).analyze();
    const violations = a11yScans.violations;
    if (violations.length > 0) {
      this.attach(JSON.stringify(violations), 'application/json');
    }
    expect(violations).toEqual([]);
  },
);
Then(
  'erwarte ich erwarte ich keine Barrierefreiheitsfehler auf diesem Eingabeformular für Erstattungsforderung-Seite',
  async function (this: ICustomWorld) {
    const page = this.page!;
    //wartet bis die Navigation abgeschlossen ist
    const a11yScans = await new AxeBuilder({ page }).analyze();
    const violations = a11yScans.violations;
    if (violations.length > 0) {
      this.attach(JSON.stringify(violations), 'application/json');
    }
    expect(violations).toEqual([]);
  },
);
Then(
  'erwarte ich keine Barrierefreiheitsfehler auf dieser Nachzahlung und Zinsen Seite',
  async function (this: ICustomWorld) {
    const page = this.page!;
    const a11yScans = await new AxeBuilder({ page }).analyze();
    const violations = a11yScans.violations;
    if (violations.length > 0) {
      this.attach(JSON.stringify(violations), 'application/json');
    }
    expect(violations).toEqual([]);
  },
);
Then(
  'erwarte ich keine Barrierefreiheitsfehler auf dieser Nachzahlung-Verzinsung-Abschluß-Seite',
  async function (this: ICustomWorld) {
    const page = this.page!;
    const a11yScans = await new AxeBuilder({ page }).analyze();
    const violations = a11yScans.violations;
    if (violations.length > 0) {
      this.attach(JSON.stringify(violations), 'application/json');
    }
    expect(violations).toEqual([]);
  },
);
Then(
  'erwarte ich keine Barrierefreiheitsfehler auf dieser Abrechnung-Anzeigen-Seite Seite',
  async function (this: ICustomWorld) {
    const page = this.page!;
    const a11yScans = await new AxeBuilder({ page }).analyze();
    const violations = a11yScans.violations;
    if (violations.length > 0) {
      this.attach(JSON.stringify(violations), 'application/json');
    }
    expect(violations).toEqual([]);
  },
);

Then('erwarte ich valides HTML', async function (this: ICustomWorld) {
  const page = this.page!;
  //wartet bis die Navigation abgeschlossen ist
  await page.waitForNavigation();
  //die Seite ist voll geladen
  await page.waitForLoadState('networkidle');

  const htmlData = await page.content();

  const options = {
    validator: 'WHATWG',
    data: htmlData,
    ignore: ['no-unknown-elements', 'no-redundant-role'],
  };
  const result = await htmlValidator(options);

  if (!result.isValid) {
    this.attach(JSON.stringify(result, null, 2));
  }
  expect(result.isValid).toBeTruthy();
});

Then('sollte ich eine 401 Antwort erhalten', function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(401);
});
Then('sollte ich eine 409 Antwort erhalten', function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(409);
});

Then('sollte ich eine 502 Antwort erhalten', function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(502);
});
Then('sollte ich eine 415 Antwort erhalten', function (this: ICustomWorld) {
  expect(this.requestResponse?.status()).toBe(415);
});
Then('sollte der Browser auf Deutsch eingestellt sein', async function (this: ICustomWorld) {
  const language = await this.page?.evaluate(() => navigator.language);
  expect(language).toMatch('de');
});

Then(
  'erscheint eine Fehlermeldung aufgrund fehlender Berechtigung',
  async function (this: ICustomWorld) {
    const berechtigungsText = await this.fehlendeBerichtigungPage?.getfehlendeBerichtigungText();
    expect(berechtigungsText).toMatch(
      /Fehlende Berechtigung|Ihre Berechtigung ist abgelaufen oder ungültig. Melden Sie sich bitte erneut in rvDialog an oder rufen Sie darüber die Versicherungsnummer erneut auf, um mit der Bearbeitung in rvSystem:modern fortzufahren./,
    );
  },
);
export function getBestandsToken() {
  return bestandsToken;
}
