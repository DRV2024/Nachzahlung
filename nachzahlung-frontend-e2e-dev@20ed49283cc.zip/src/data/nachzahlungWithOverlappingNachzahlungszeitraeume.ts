export const createNachzahlungWithOverlappingNachzahlungsZeitraeume = (vorgangsId: string) => {
  const nachzahlungsZeitraeume = [
    {
      zeitraum: {
        von: '2023-01-01',
        bis: '2023-01-15',
      },
      betragNettoMonatlich: 1,
      beitragsanteilRentnerKV: 10,
      beitragsanteilTraegerKV: 0,
      zusatzbeitragRentnerKV: 1,
      zusatzbeitragTraegerKV: 10,
      beitragRentnerPV: 0,
      kvdrVerhaeltnis: 1,
    },
    {
      zeitraum: {
        von: '2023-01-15', // Überschneidungen mit dem ersten Eintrag
        bis: '2023-02-01',
      },
      betragNettoMonatlich: 1,
      beitragsanteilRentnerKV: 10,
      beitragsanteilTraegerKV: 0,
      zusatzbeitragRentnerKV: 1,
      zusatzbeitragTraegerKV: 10,
      beitragRentnerPV: 0,
      kvdrVerhaeltnis: 1,
    },
  ];

  return {
    resourcen: [
      {
        vorgangsId: vorgangsId,
        bescheiddatum: '2023-01-01',
        bescheidnummer: '01',
        eingangsdatumRentenantrag: '2023-01-01',
        ktan: '12',
        leistungsart: '10',
        nachzahlungsbetragGesamt: 10,
        rentenbeginn: '2023-01-01',
        zahlungsauftragNummer: 1,
        zahlweise: 'VORSCHUESSIG',
        zeitraum: {
          von: '2023-01-01',
          bis: '2023-02-01',
        },
        rentenberechtigter: {
          vorgangsId: vorgangsId,
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null,
        },
        versicherter: {
          vorgangsId: vorgangsId,
          vsnr: '12345678X012',
          adressat: '0002',
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null,
        },
        nachzahlungsZeitraeume: nachzahlungsZeitraeume,
        aufstellungsdatum: null,
        erstattungsForderungsEingaenge: [
          {
            vorgangsId: vorgangsId,
            aktenzeichen: 'XY',
            verfahrensstand: 'PAPIER',
            erstattungsstelle: {
              name: 'schöner Name',
              adressschluessel: '000000123',
            },
            forderungsZeitraeume: [
              {
                betragForderung: 1.0,
                zeitraum: {
                  von: '2023-01-01',
                  bis: '2023-01-31',
                },
                auszahlungsjahr: 2023,
              },
            ],
          },
        ],
      },
    ],
    size: 1,
  };
};
