import { format, subMonths, startOfMonth, endOfMonth, addDays } from 'date-fns';

export const createNachzahlungenTF48POST = (vorgangsId: string) => {
  const currentDate = new Date();
  const sixMonthsAgo = subMonths(currentDate, 6);
  const sevenMonthsAgoStart = startOfMonth(subMonths(currentDate, 7));
  const sevenMonthsAgoEnd = endOfMonth(subMonths(currentDate, 7));
  const sixtMonthsAgoAddTwoDays = addDays(subMonths(currentDate, 6), 2);

  return {
    resourcen: [
      {
        vorgangsId: vorgangsId,
        bescheiddatum: format(sixtMonthsAgoAddTwoDays, 'yyyy-MM-dd'),
        bescheidnummer: '01',
        eingangsdatumRentenantrag: format(sixMonthsAgo, 'yyyy-MM-dd'),
        ktan: '17',
        leistungsart: '10',
        nachzahlungsbetragGesamt: 800,
        rentenbeginn: format(sevenMonthsAgoStart, 'yyyy-MM-dd'),
        zahlungsauftragNummer: 1,
        zahlweise: 'NACHSCHUESSIG',
        zeitraum: {
          von: format(sevenMonthsAgoStart, 'yyyy-MM-dd'),
          bis: format(sevenMonthsAgoEnd, 'yyyy-MM-dd'),
        },
        rentenberechtigter: {
          vorgangsId: vorgangsId,
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null,
        },
        versicherter: {
          vorgangsId: vorgangsId,
          vsnr: '12345678X048',
          adressat: '0002',
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null,
        },
        nachzahlungsZeitraeume: [
          {
            zeitraum: {
              von: format(sevenMonthsAgoStart, 'yyyy-MM-dd'),
              bis: format(sevenMonthsAgoEnd, 'yyyy-MM-dd'),
            },
            betragNettoMonatlich: 800,
            beitragsanteilRentnerKV: 10,
            beitragsanteilTraegerKV: 0,
            zusatzbeitragRentnerKV: 1,
            zusatzbeitragTraegerKV: 10,
            beitragRentnerPV: 0,
            kvdrVerhaeltnis: 1,
          },
        ],
        aufstellungsdatum: format(currentDate, 'yyyy-MM-dd'),
        erstattungsForderungsEingaenge: [
          {
            vorgangsId: vorgangsId,
            aktenzeichen: 'XY',
            verfahrensstand: 'PAPIER',
            erstattungsstelle: {
              name: 'schöner Name',
              adressschluessel: '000000048',
            },
          },
        ],
      },
    ],
  };
};
