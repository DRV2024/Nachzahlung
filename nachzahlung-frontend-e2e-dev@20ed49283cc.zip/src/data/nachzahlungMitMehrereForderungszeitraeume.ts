export const createNachzahlungMitMehrereForderungsZeitraeume = (
  vorgangsId: string,
  count: number, // Diese Zahl sollte 100 sein, um 100 Einträge zu erstellen.
) => {
  const forderungsZeitraeume = [];
  let currentStartDay = 1; // Beginn am 1. Januar 2023

  for (let i = 0; i < count; i++) {
    const startDatum = new Date(2023, 0, currentStartDay); // Startdatum basierend auf dem aktuellen Tag
    const endDatum = new Date(2023, 0, currentStartDay + 2); // Enddatum ist 2 Tage später, total 3 Tage

    forderungsZeitraeume.push({
      betragForderung: 1.0,
      zeitraum: {
        von: startDatum.toISOString().slice(0, 10),
        bis: endDatum.toISOString().slice(0, 10),
      },
      auszahlungsjahr: 2023,
    });

    currentStartDay += 3; // Verschiebt den Starttag um 3 für den nächsten Eintrag
  }

  return {
    resourcen: [
      {
        vorgangsId,
        bescheiddatum: '2023-01-01',
        bescheidnummer: '01',
        eingangsdatumRentenantrag: '2023-01-01',
        ktan: '70',
        leistungsart: '10',
        nachzahlungsbetragGesamt: 10,
        rentenbeginn: '2023-01-01',
        zahlungsauftragNummer: 1,
        zahlweise: 'VORSCHUESSIG',
        zeitraum: {
          von: '2023-01-01',
          bis: '2023-12-31'
        },
        rentenberechtigter: {
          vorgangsId,
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null,
        },
        versicherter: {
          vorgangsId,
          vsnr: '12345678X012',
          adressat: '0002',
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null,
        },
        nachzahlungsZeitraeume: [
          {
            zeitraum: {
              von: '2023-01-01',
              bis: '2023-12-31'
            },
            betragNettoMonatlich: 1,
            beitragsanteilRentnerKV: 10,
            beitragsanteilTraegerKV: 0,
            zusatzbeitragRentnerKV: 1,
            zusatzbeitragTraegerKV: 10,
            beitragRentnerPV: 0,
            kvdrVerhaeltnis: 1
          }
        ],
        aufstellungsdatum: null,
        erstattungsForderungsEingaenge: [
          {
            vorgangsId,
            aktenzeichen: 'XY',
            verfahrensstand: 'PAPIER',
            erstattungsstelle: {
              name: 'schöner Name',
              adressschluessel: '000000123',
            },
            forderungsZeitraeume,
          },
        ],
      },
    ],
    size: 1,
  };
};
