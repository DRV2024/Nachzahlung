export const createNachzahlungMitMehrereErstattungsforderungen = (
  vorgangsId: string,
  count: number,
) => {
  const erstattungsForderungsEingaenge = [];
  for (let i = 1; i <= count; i++) {
    erstattungsForderungsEingaenge.push({
      vorgangsId: vorgangsId,
      aktenzeichen: `XY-${i}`, // Dynamisches Aktenzeichen für Eindeutigkeit
      verfahrensstand: 'PAPIER',
      erstattungsstelle: {
        name: `Name ${i}`, // Dynamischer Name für jede Erstattungsforderung
        adressschluessel: `000000${123 + i}`, // Eindeutiger Adressschlüssel
      },
    });
  }

  return {
    resourcen: [
      {
        vorgangsId: vorgangsId,
        bescheiddatum: '2023-01-01',
        bescheidnummer: '01',
        eingangsdatumRentenantrag: '2023-01-01',
        ktan: '70',
        leistungsart: '10',
        nachzahlungsbetragGesamt: 10,
        rentenbeginn: '2023-01-01',
        zahlungsauftragNummer: 1,
        zahlweise: 'VORSCHUESSIG',
        zeitraum: {
          von: '2023-01-01',
          bis: '2024-02-01',
        },
        rentenberechtigter: {
          vorgangsId: vorgangsId,
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null,
        },
        versicherter: {
          vorgangsId: vorgangsId,
          vsnr: '12345678X012',
          adressat: '0002',
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null,
        },
        nachzahlungsZeitraeume: [
          {
            zeitraum: {
              von: '2023-01-01',
              bis: '2024-02-01',
            },
            betragNettoMonatlich: 1,
            beitragsanteilRentnerKV: 10,
            beitragsanteilTraegerKV: 0,
            zusatzbeitragRentnerKV: 1,
            zusatzbeitragTraegerKV: 10,
            beitragRentnerPV: 0,
            kvdrVerhaeltnis: 1,
          },
        ],
        aufstellungsdatum: null,
        erstattungsForderungsEingaenge: erstattungsForderungsEingaenge,
      },
    ],
    size: 1,
  };
};
