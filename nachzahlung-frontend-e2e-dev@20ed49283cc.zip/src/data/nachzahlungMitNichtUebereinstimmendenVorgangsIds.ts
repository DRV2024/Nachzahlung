import { generateVorgangsId } from '../steps/api/nachzahlungenPOST.steps';

export const createMismatchedNachzahlung = (
  scenario: 'versicherte' | 'rentenberechtigter' | 'erstattungsForderungsEingaenge',
) => {
  const vorgangsIdHaupt = generateVorgangsId(); // Haupt-VorgangsId
  const vorgangsIdAnders = generateVorgangsId(); // Unterschiedliche VorgangsId für das ausgewählte Szenario

  const nachzahlungData = {
    vorgangsId: vorgangsIdHaupt,
    bescheiddatum: '2023-01-01',
    bescheidnummer: '01',
    eingangsdatumRentenantrag: '2023-01-01',
    ktan: '12',
    leistungsart: '10',
    nachzahlungsbetragGesamt: 10,
    rentenbeginn: '2023-01-01',
    zahlungsauftragNummer: 1,
    zahlweise: 'VORSCHUESSIG',
    zeitraum: {
      von: '2023-01-01',
      bis: '2023-02-01',
    },
    rentenberechtigter: {
      vorgangsId: scenario === 'rentenberechtigter' ? vorgangsIdAnders : vorgangsIdHaupt,
      adressnummer: '11',
      nachname: 'Mustermann',
      namenszusatz: null,
      titel: null,
      vorname: 'Max',
      vorsatzwort: null,
    },
    versicherter: {
      vorgangsId: scenario === 'versicherte' ? vorgangsIdAnders : vorgangsIdHaupt,
      vsnr: '12345678X012',
      adressat: '0002',
      adressnummer: '11',
      nachname: 'Mustermann',
      namenszusatz: null,
      titel: null,
      vorname: 'Max',
      vorsatzwort: null,
    },
    erstattungsForderungsEingaenge:
      scenario === 'erstattungsForderungsEingaenge'
        ? [
          {
            vorgangsId: vorgangsIdAnders,
            aktenzeichen: 'XY',
            verfahrensstand: 'PAPIER',
              erstattungsstelle: {
                name: 'schöner Name',
              adressschluessel: '000000123',
            },
          },
        ]
        : [
          {
            vorgangsId: vorgangsIdHaupt,
            aktenzeichen: 'XY',
            verfahrensstand: 'PAPIER',
            erstattungsstelle: {
              name: 'schöner Name',
              adressschluessel: '000000123',
            },
          },
        ],
  };

  return nachzahlungData;
};
