export const createBodyNachzahlungenPOSTWithInvalidDateRange = (vorgangsId: string) => {
  return {
    resourcen: [
      {
        vorgangsId: vorgangsId,
        bescheiddatum: '2023-01-01',
        bescheidnummer: '01',
        eingangsdatumRentenantrag: '2023-01-01',
        ktan: '70', // KTAN wurde auf 70 geändert
        leistungsart: '10',
        nachzahlungsbetragGesamt: 10,
        rentenbeginn: '2023-01-01',
        zahlungsauftragNummer: 1,
        zahlweise: 'VORSCHUESSIG',
        zeitraum: {
          von: '2023-01-01',
          bis: '2023-02-01'
        },
        rentenberechtigter: {
          vorgangsId: vorgangsId,
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null
        },
        versicherter: {
          vorgangsId: vorgangsId,
          vsnr: '12345678X012',
          adressat: '0002',
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorname: 'Max',
          vorsatzwort: null
        },
        nachzahlungsZeitraeume: [
          {
            zeitraum: {
              von: '2022-03-01',
              bis: '2022-04-01'
            },
            betragNettoMonatlich: 1,
            beitragsanteilRentnerKV: 10,
            beitragsanteilTraegerKV: 0,
            zusatzbeitragRentnerKV: 1,
            zusatzbeitragTraegerKV: 10,
            beitragRentnerPV: 0,
            kvdrVerhaeltnis: 1
          }
        ],
        erstattungsForderungsEingaenge: [
          {
            vorgangsId: vorgangsId,
            forderungsZeitraeume: [
              {
                betragForderung: 430.0,
                zeitraum: {
                  von: '2024-01-01',  // Synchronisiert mit dem ungültigen Nachzahlungszeitraum
                  bis: '2024-02-01',
                },
                auszahlungsjahr: 2024
              }
            ],
            erstattungsstelle: {
              name: 'Erstattungsstelle',
              adressschluessel: 'R80'
            },
            verfahrensstand: 'DATENSATZ_EINGELAUFEN',
            buchungszeichen: null,
            aktenzeichen: null,
            rechtsgrundlage: 'SGB103X'
          },
        ],
        aufstellungsdatum: null
      }
    ],
    size: 1,
  };
};
