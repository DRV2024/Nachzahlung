export const createNachzahlungMitMehrereZeitraueme = (vorgangsId: string, count: number) => {
  const nachzahlungsZeitraeume = [];
  const datum = new Date(2023, 0, 1); // Startdatum: 01.01.2023

  for (let i = 0; i < count; i++) {
    nachzahlungsZeitraeume.push({
      zeitraum: {
        von: datum.toISOString().slice(0, 10),
        bis: datum.toISOString().slice(0, 10), // Gleiches Datum für "von" und "bis"
      },
      betragNettoMonatlich: i % 2 === 0 ? 20 : 30,
      beitragsanteilRentnerKV: 10,
      beitragsanteilTraegerKV: 0,
      zusatzbeitragRentnerKV: 1,
      zusatzbeitragTraegerKV: 10,
      beitragRentnerPV: 0,
      kvdrVerhaeltnis: 1,
    });

    datum.setDate(datum.getDate() + 1); // Datum um einen Tag erhöhen
  }

  return {
    resourcen: [
      {
        vorgangsId: vorgangsId,
        bescheiddatum: '2023-01-01',
        bescheidnummer: '01',
        eingangsdatumRentenantrag: '2023-01-01',
        ktan: '70',
        leistungsart: '10',
        nachzahlungsbetragGesamt: 10,
        nachzahlungsZeitraeume: nachzahlungsZeitraeume, // Array mit den generierten Einträgen
        rentenbeginn: '2023-01-01',
        rentenberechtigter: {
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorgangsId: vorgangsId,
          vorname: 'Max',
          vorsatzwort: null,
        },
        versicherter: {
          adressat: '0002',
          adressnummer: '11',
          nachname: 'Mustermann',
          namenszusatz: null,
          titel: null,
          vorgangsId: vorgangsId,
          vorname: 'Max',
          vsnr: '12345678X012',
        },
        zahlungsauftragNummer: 1,
        zahlweise: 'VORSCHUESSIG',
        zeitraum: {
          bis: '2023-12-31',
          von: '2023-01-01',
        },
        aufstellungsdatum: null,
      },
    ],
    size: 1,
  };
};
